

<?php
session_start();
require 'fpdf.php';


$head=$_SESSION['head'];
$body=$_SESSION['body'];
$split=$_SESSION['split'];

$table_header=array();
$table_body=array();
$counter=0;
$word="";
$ar_size=0;
$body_size=0;
$date="Printed on:".date("d/m/Y") ;
$fpdf= new fpdf('p','mm','A4');
$fpdf->AddPage();






$fpdf->Image('../images/eye.png',10,10);
$fpdf->SetFont('Courier','I',10);
$fpdf->SetTextColor(123,120,90);
$fpdf->SetX(35);

$fpdf->Cell(50,5,"Mobile: 01000670562 01000670498","I");
$fpdf->Ln(5);
$fpdf->SetX(35);
$fpdf->Cell(50,5,"Address:","I");
$fpdf->SetX($fpdf->GetPageWidth()/1.5);
$fpdf->SetTextColor(0,0,0);
$fpdf->Cell(50,5,$date,"I");
$fpdf->Ln(25);

$fpdf->SetTextColor(0,0,0);
$fpdf->SetX($fpdf->GetPageWidth()/3);
$fpdf->SetFont('Courier','B',25);
$fpdf->Cell(50,5,"Invoice","I");
$fpdf->Ln(8);
$fpdf->SetTextColor(0,0,0);
$fpdf->SetFont('Arial','B',16);





while ($counter<strlen($head)){
    if(strcmp($head[$counter],$split)){
        $word.=$head[$counter];



    }else{

        array_push($table_header,$word);
        $word="";



    }



    $counter++;

}




$ar_size=count($table_header);



for ($i=0;$i<$ar_size;$i++){
    if($i+1==$ar_size){

        $fpdf->Cell('40', '10', $table_header[$i], 1,1);

    }else{
        $fpdf->Cell('40', '10', $table_header[$i], 1);


    }


}



$counter=0;
while ($counter<strlen($body)){
    if(strcmp($body[$counter],$split)){
        $word.=$body[$counter];



    }else{

        array_push($table_body,$word);
        $word="";



    }



    $counter++;




    $body_size=count($table_body);
}



$fpdf->SetFont('Arial','B',13);
$counter=0;
for ($i=0;$i<$body_size;$i++){
    if($counter!=$ar_size-1) {
        $fpdf->Cell('40', '10', $table_body[$i], 1);
    }else{

        $fpdf->Cell('40', '10', $table_body[$i], 1,1);

    }$counter++;







}








 $fpdf->Output();







?>

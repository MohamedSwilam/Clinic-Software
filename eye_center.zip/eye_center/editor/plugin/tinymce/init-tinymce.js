tinymce.init({
    selector: "textarea.tinymce",
    theme: "modern",
});
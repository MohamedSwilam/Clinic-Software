<?php
require_once '../php/model/html.php';

$h1 = new html();

$pageClassName = 'about_us';
$result = $h1->read_page($pageClassName);

if (!empty($result)) {
    foreach ($result as $value) {
        $html = $value['html'];
    }
}
?>
<html>
    <head>
        <title>Editor</title>
        <link rel="stylesheet" type="text/css" href="../css/index.css">
    </head>
    <body>
        <div class="title"><strong>Edit your page</strong></div>
        <form method="POST" action="">
            <textarea class = "tinymce" rows="20" cols="100" id = "myTextarea"><?php echo $html ?></textarea>
            <button class="btn-update btn" type="submit" id="submit" >Update</button> 
            <p id="test"></p>
        </form>

        <!--- js --->
        <script type="text/javascript" src = "../editor/js/jquery.min.js"></script>
        <script type="text/javascript" src="../editor/plugin/tinymce/tinymce.min.js"></script>
        <script type="text/javascript" src="../editor/plugin/tinymce/init-tinymce.js"></script>
        <script src="../js/editor.js"></script>

    </body>
</html>
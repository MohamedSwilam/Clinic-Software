<?php 
      echo' <div class="block">
         <div class="title"><center><strong>Add Medicine</strong></center</div></div>                    
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group-material">
                                            <input id="medicine-name" type="text" name="medicine-name" required class="input-material">
                                            <label for="medicine-name" class="label-material">Medicine Name</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="medicine-category" type="email" name="medicine-category" required class="input-material">
                                            <label for="medicine-category" class="label-material">Medicine Category</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="expired-date" name="expired-date" required class="input-material">
                                            <label for="expired-date" class="label-material">Expired Date </label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="Specifications" name="Specifications" required class="input-material">
                                            <label for="Specifications" class="label-material">Specifications</label>
                                        </div>
                                        <div class="line"></div>
                                <div class="form-group row">
                                    <div class="col-sm-9 ml-auto">
                                        <button type="submit" class="btn btn-secondary">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </div>
                            </div>';
?>
<html>
<body>
        <script src="../../js/libraries/jquery-3.2.1.min.js"></script>
        <script src="../../js/libraries/bootstrap.min.js"></script>
        <script src="../../js/libraries/front.js"></script>
        <script src="../../js/profile.js"></script>

</body>
</html>
<html>


<head>

<link rel="stylesheet" href="../../css/table-code.css">

</head>


<body>
<?php

echo '

<div>
    <label class="col-sm-3 form-control-label">Search Patient</label>
                                    <br>
                                    <div class="col-sm-9">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <button data-toggle="dropdown" type="button" class="btn btn-outline-secondary dropdown-toggle">Action <span class="caret"></span></button>
                                                <div class="dropdown-menu"><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Another action</a><a href="#" class="dropdown-item">Something else here</a>
                                                    <div class="dropdown-divider"></div><a href="#" class="dropdown-item">Separated link</a>
                                                </div>
                                            </div>
                                            <input type="text" class="form-control">
                                        </div>
                                    </div>
  
  <br><br>
    <table  class="table own-table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Date</th>
            <th scope="col">Patient name</th>
            <th scope="col">amount paid</th>
            <th scope="col">Notes</th>


        </tr>
        </thead>
        <tbody>
        <tr>


            <td>1/5/2015</td>
            <td>mostafa</td>
            <td>500</td>
            <td>dafa3 500 w ba2y 100</td>

        </tr>

        </tbody>
    </table>


</div>';
?>

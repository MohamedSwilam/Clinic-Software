<?php 
      echo' <div class="block">
         <div class="title"><center><strong>Make Surgery</strong></center</div></div>                    
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group-material">
                                            <input id="patient-name" type="text" name="patient-name" required class="input-material">
                                            <label for="patient-name" class="label-material">Patient Name</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="mobile" type="email" name="mobile" required class="input-material">
                                            <label for="mobile" class="label-material">Mobile</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="id" name="id" required class="input-material">
                                            <label for="id" class="label-material">ID</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="date" name="date" required class="input-material" type="date">
                                            <label for="date" class="label-material"></label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="duration" name="duration" required class="input-material">
                                            <label for="duration" class="label-material">Duration</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="price" name="price" required class="input-material">
                                            <label for="price" class="label-material">Price</label>
                                        </div>
                                        <div class="form-group-material">
                                            <input id="notes" name="notes" required class="input-material">
                                            <label for="price" class="label-material">Some Notes About The Surgery</label>
                                        </div>
                                        <div class="line"></div>
                                <div class="form-group row">
                                    <div class="col-sm-9 ml-auto">
                                        <button type="submit" class="btn btn-secondary">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </div>';
?>
<html>
<body>
        <script src="../../js/libraries/jquery-3.2.1.min.js"></script>
        <script src="../../js/libraries/bootstrap.min.js"></script>
        <script src="../../js/libraries/front.js"></script>
        <script src="../../js/profile.js"></script>

</body>
</html>
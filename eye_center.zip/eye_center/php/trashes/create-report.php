<?php
echo'<div class="block">
         <div class="title"><center><strong>Create Medical Report</strong></center</div></div>
       
            <div class="report-table" >
            <table class="table table-bordered table-hover" >
            <thead class="bg-primary">
                <tr class="text-center">
                    <th >Left</th>
      				<th>Right</th>
                </tr>
            </thead>
            <tbody>
                <tr class="text-center">
                    <th>1</th>
                      <th>1</th>
                </tr>
                <tr class="text-center">
                    <th>2 / .5 x 4 </th>
      				<th >2 / 1.5 x 4 </th>
                </tr>
                <tr class="text-center">
                    <th>3</th>
                    <th>1</th>
                </tr>
                <tr class="text-center">
                    <th>4</th>
                    <th>2.5</th>
                </tr>
                
            </tbody>
        </table>
                <br>
        <table class="table table-bordered table-hover">
        <tbody>
                <tr class="text-center">
                    <th>1</th>
                      <th>1</th>
                </tr>
                <tr class="text-center">
                    <th>3 </th>
      				<th >4</th>
                </tr>
                <tr class="text-center">
                    <th>3</th>
                    <th>1</th>
                </tr>
               
                
            </tbody>
        </table>
                <br>
                <table class="table table-bordered table-hover">
        <tbody>
                <tr class="text-center">
                    <th>2 / .5 x 4 </th>
                      <th>2 / .5 x 4 </th>
                </tr>
                <tr class="text-center">
                    <th>1</th>
      				<th >2</th>
                </tr>
                <tr class="text-center">
                    <th>3</th>
                    <th>1</th>
                </tr>
               
                
            </tbody>
        </table>
              
</div>';
?>
<html>
<body>
        <script src="../../js/libraries/jquery-3.2.1.min.js"></script>
        <script src="../../js/libraries/bootstrap.min.js"></script>
        <script src="../../js/libraries/front.js"></script>
        <script src="../../js/profile.js"></script>

</body>
</html>
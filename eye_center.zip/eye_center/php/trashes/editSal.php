<html>

<head>

    <link rel="stylesheet" href="../../css/table-code.css">

</head>
<body>




</html>
<?php

echo '  
  <label class="col-sm-3 form-control-label">Search Employee</label>
                                    <br>
                                    <div class="col-sm-9">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <button data-toggle="dropdown" type="button" class="btn btn-outline-secondary dropdown-toggle">Action <span class="caret"></span></button>
                                                <div class="dropdown-menu"><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Another action</a><a href="#" class="dropdown-item">Something else here</a>
                                                    <div class="dropdown-divider"></div><a href="#" class="dropdown-item">Separated link</a>
                                                </div>
                                            </div>
                                            <input type="text" class="form-control">
                                        </div>
                                    </div>
  
  
                                   <br>
                                <br>
                                
                                <table  class="table own-table">

      <thead class="thead-dark">
                                <tr id="table-head">
        <th  scope="col">employee Id</th>
        <th  scope="col" >employee name</th>
        <th  scope="col">Type</th>
        <th  scope="col">salary</th>
        <th  scope="col">rewards</th>
        <th  scope="col">discounts</th>
        <th  scope="col">Total</th>

    </tr>
     </thead>
      <tbody>
    <tr >


        <td><input type="text" value="1"></td>
        <td><input type="text" value="mostafa"> </td>
        <td><input type="text" value="doctor" </td>
        <td><input type="text" value="1"></td>
        <td><input type="text" value="2"> </td>
        <td><input type="text" value="3"> </td>
        <td><input type="text" value="4"></td>
        <td><button>Submit</button></td>
    </tr>

                            </tbody>
<table>';








?>
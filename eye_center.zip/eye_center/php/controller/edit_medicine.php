<?php

require_once '../model/medecine.php';


$obj = new medecine();
$id = $_POST['id'];
$medecine_Name = $_POST['name'];
$category_name = $_POST['catid'];

$data = array();
array_push($data, $id);
array_push($data, $medecine_Name);
array_push($data, $category_name);

$result = $obj->update($data);
echo $result;
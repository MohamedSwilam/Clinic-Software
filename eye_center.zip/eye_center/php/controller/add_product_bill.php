<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/13/18
 * Time: 8:41 PM
 */
require_once '../model/bill.php';
$paid=$_POST['paid'];
$total=$_POST['total'];
$is_in=$_POST['is_in'];
$arr=array($paid,$total,$is_in);
$obj= new  bill();
if($obj->add_product_bill($arr)){

    $result=$obj->get_maxId();

    foreach ($result as $row){


        echo  $row['MAX(id)'];

    }


}
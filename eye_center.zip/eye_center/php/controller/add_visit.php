<?php

include_once '../model/visit.php';
include_once '../model/reservation.php';
include_once '../model/reservation_observer.php';

$reservationID = $_POST['reservationID'];
$date = $_POST['date'];
$time = $_POST['time'];
$doctorID;
$r1 = new reservation();

$v1 = new visit();

$result2 = $r1->getDoctorID();
foreach ($result2 as $value) {
    $doctorID = $value['doctor_id'];
}
$notfication_type_id = "1";
$observer = new reservation_observer($doctorID, $notfication_type_id);
$v1->attach($observer);
$v1->notify();




$data = array($reservationID, $date, $time);
$result = $v1->create($data);
echo $result;

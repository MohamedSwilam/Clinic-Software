<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require '../model/product_type.php';

$PT= new product_type();
$type_name=$_POST['type_name'];
$data[0]=$type_name;
$PT->create($data);


<?php
include_once '../model/reservation.php';
$r1 = new reservation();

$patientID = $_POST['patientID'];
$data = array($patientID);
$result = $r1->delete($data);
echo $result;
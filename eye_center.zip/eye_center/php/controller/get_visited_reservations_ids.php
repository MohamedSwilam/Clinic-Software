<?php

include_once '../model/visit.php';

$v1 = new visit();

$result = $v1->getVisitedReservationsIDs();
if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['reservation_id'];
        } else {
            echo $value['reservation_id'] . "~";
            $i++;
        }
    }
}
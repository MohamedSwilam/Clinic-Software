<?php

include_once '../model/visit.php';
require_once '../model/notification_observer.php';

$statusID = $_POST['statusID'];
$reservationID = $_POST['reservationID'];

$v1 = new visit();


$data = array($statusID, $reservationID);
$result = $v1->update($data);
echo $result;

$notfication_type_id = "1";
$receptionistID = "4";
$userTypeID = $receptionistID;

switch ($statusID) {
    case "3": //Postponed
        $notfication_type_id = "2";
        break;
    case "4"://Finished
        $notfication_type_id = "3";
        break;
    default:
        $notfication_type_id = "non";
        break;
}


$observer = new notification_observer($userTypeID, $notfication_type_id);
$v1->attach($observer);
$v1->notify();
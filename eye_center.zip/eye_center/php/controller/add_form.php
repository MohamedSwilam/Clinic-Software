<?php

include_once '../model/option.php';
include_once '../model/form_code.php';
include_once '../model/form_type.php';
include_once '../model/form_user_access.php';
include_once '../model/form_option.php';

$msg = TRUE;

if (isset($_POST['formName'])) {
    $formName = $_POST['formName'];
} else {
    $msg = "Please, enter form name!";
}

if (isset($_POST['usersAccess']) && !empty($_POST['usersAccess'])) {
    $usersAccess = $_POST['usersAccess'];
} else {
    $msg = "Please Enter Users to access this form";
}

if (isset($_POST['code'])) {
    $code = $_POST['code'];
} else {
    $msg = "No Code Generated";
}

if (isset($_POST['options'])) {
    $options = $_POST['options'];
} else {
    $msg = "You Should Select at least 1 Input!";
}

$optionsRequired = $_POST['optionsRequired'];

if (isset($_POST['oldOptionsIndex'])) {
    $oldOptionsIndex = $_POST['oldOptionsIndex'];
} else {
    $oldOptionsIndex = array();
}

if (isset($_POST['multiOptionalOptions'])) {
    $multiOptionalOptions = $_POST['multiOptionalOptions'];
} else {
    $multiOptionalOptions = array();
}

if (isset($_POST['medicine'])) {
    $medicine = $_POST['medicine'];
} else {
    $msg = "Medicine is not declared!";
}

if (isset($_POST['optionsType'])) {
    $optionsType = $_POST['optionsType'];
} else {
    $msg = "Options type is not declared!";
}

if ($msg == TRUE) {
    $counterOld = 0;
    $counterMultiple = 0;
    $incrementCounter = FALSE;
    $o1 = new option();
    for ($i = 0; $i < count($options); $i++) {
        if ($counterOld < count($oldOptionsIndex)) {
            if ($i == $oldOptionsIndex[$counterOld] - 1) {
                $result = $o1->checkIdAvailable($options[$i], $optionsType[$i]);
                if ($result == FALSE) {
                    $msg = "Option Not Found ";
                    break;
                }
                $incrementCounter = TRUE;
            } else {
                $optionNotExist = $o1->checkOptionAvailable($options[$i], $optionsType[$i]);
                if ($optionNotExist == FALSE) {
                    $data = array($options[$i], $optionsType[$i], 0);
                    $result = $o1->create($data);
                    if ($result != FALSE) {
                        $options[$i] = $result;
                        if (isset($multiOptionalOptions[$counterMultiple][0])) {
                            if ($multiOptionalOptions[$counterMultiple][0] - 1 == $i) {
                                for ($j = 0; $j < count($multiOptionalOptions[$counterMultiple]); $j++) {
                                    if ($j != 0) {
                                        $data = array($multiOptionalOptions[$counterMultiple][$j], 11, $options[$i], 0);
                                        $result = $o1->create($data);
                                        if ($result == FALSE) {
                                            $msg = "Failed! #002";
                                            break;
                                        }
                                    }
                                }
                                $counterMultiple++;
                            }
                        }
                    }
                } else {
                    echo "Input of name '" . $options[$i] . "' already exists!";
                    $msg = "Input of name '" . $options[$i] . "' already exists!";
                    $msg = FALSE;
                    break;
                }
            }
        } else {
            $optionNotExist = $o1->checkOptionAvailable($options[$i], $optionsType[$i]);
            if ($optionNotExist == FALSE) {
                $data = array($options[$i], $optionsType[$i], 0);
                $result = $o1->create($data);
                if ($result != FALSE) {
                    $options[$i] = $result;
                    if (isset($multiOptionalOptions[$counterMultiple][0])) {
                        if ($multiOptionalOptions[$counterMultiple][0] - 1 == $i) {
                            for ($j = 0; $j < count($multiOptionalOptions[$counterMultiple]); $j++) {
                                if ($j != 0) {
                                    $data = array($multiOptionalOptions[$counterMultiple][$j], 11, $options[$i], 0);
                                    $result = $o1->create($data);
                                    if ($result == FALSE) {
                                        $msg = "Failed! #002";
                                        break;
                                    }
                                }
                            }
                            $counterMultiple++;
                        }
                    }
                }
            } else {
                echo "Input of name '" . $options[$i] . "' already exists!";
                $msg = "Input of name '" . $options[$i] . "' already exists!";
                $msg = FALSE;
                break;
            }
        }
        if ($incrementCounter == TRUE) {
            $counterOld++;
            $incrementCounter = FALSE;
        }
    }

    if ($msg != TRUE) {
        echo $msg;
    } else {
        $fc = new form_code();
        $codeData = array($code);
        $codeID = $fc->create($codeData);
        //echo $codeID;
        if ($codeID != FALSE) {
            $ft = new form_type();
            $formTypeData = array($formName, $codeID, $medicine, 1);
            $formTypeID = $ft->create($formTypeData);
            if ($formTypeID != FALSE) {
                $fuc = new form_user_access();
                for ($i = 0; $i < count($usersAccess); $i++) {
                    $fucData = array($usersAccess[$i], $formTypeID);
                    $result = $fuc->create($fucData);
                }
                $fo = new form_option();
                for ($i = 0; $i < count($options); $i++) {
                    $foData = array($options[$i], $formTypeID, $optionsRequired[$i]);
                    $result = $fo->create($foData);
                }
            }
        }
        echo $result;
    }
} else {
    echo $msg;
}
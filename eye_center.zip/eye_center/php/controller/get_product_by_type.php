<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require '../model/product.php';

$p=new product();
$type_id=$_POST['typeID'];
$result=$p->get_product_by_typeid($type_id);


if (!empty($result)){
    $i = 0;
    foreach ($result as $value) {
        
            if ($i == count($result) - 1){
                echo $value['id'] . "~" . $value['name'];
            } else {
                echo $value['id'] . "~" . $value['name'] . "~";
                $i++;
            }
        
    }
}





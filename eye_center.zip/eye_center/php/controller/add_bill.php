<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 4/29/18
 * Time: 7:02 PM
 */
include_once '../model/bill.php';
$amount=$_POST['amount'];
$arr=array($amount);


$bill_object= new bill();
if($bill_object->create($arr)){


    echo true;

}
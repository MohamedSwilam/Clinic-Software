



<?php

//include_once '../model/user.php';
include_once '../model/product.php';
include_once '../model/product_type_info_option.php';
include_once '../model/product_type_info_value.php';
include_once '../model/product_type_info.php';


$PTI = new product_type_info();
$ptiO = new product_type_info_option();
$ptiV = new product_type_info_value();

$type_id = $_POST['type_id'];
$product_id = $_POST['product_id'];
$type_products_info_id=NULL;
$option_id=NULL;
$result1 = $PTI->get_All_type_options($type_id);
if (!empty($result1)) {

    $i = 0;
    foreach ($result1 as $value) {
        $result2 = $PTI->getid($type_id, $value['option_id']);
        $option_id[$i] = $value['option_id'];
        if (!empty($result2)) {
            foreach ($result2 as $value2) {
                $type_products_info_id[$i] = $value['id'];
                $i++;
            }
        }
    }
}


$option_values=NULL;
 $option_values_id=NULL;

for ($j = 0; $j < count($type_products_info_id); $j++) {
    $result3 = $ptiV->get_value($type_products_info_id[$j]);
    if (!empty($result3)) {
        foreach ($result3 as $value3) {
            $option_values[$j] = $value3['value'];
            $option_values_id[$j] = $value3['id'];
        }
    }
}

$option_names=NULL;
for ($j = 0; $j < count($option_id); $j++) {
    $result4 = $ptiO->get_option_by_id($option_id[$j]);
            
    if (!empty($result4)) {
        foreach ($result4 as $value4) {
            
            $option_names[$j] = $value4['name'];
        }
    }
}


echo count($type_products_info_id)."zzzzz/zzzzz".count($option_values)."zzzzzzzzz/zzzzzzzzzzz".count($option_values_id)."zzzzzzzzz/zzzzzzzzzzz".count($option_names)."zzzzzzzzz/zzzzzzzzzzz";
for ($j = 0; $j < count($option_values); $j++) {

    if ($i == count($type_products_info_id) - 1) {
        echo $type_products_info_id[$j] . "~" . $option_values[$j] . "~" . $option_names[$j]. "~" .$option_values_id[$j] ;
    } else {
        echo $type_products_info_id[$j] . "~" . $option_values[$j] . "~" . $option_names[$j] . "~" .$option_values_id[$j]. "!^@";
      
    }
      $i++;
}

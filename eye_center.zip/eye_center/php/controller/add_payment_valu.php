<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 5:02 PM
 */

require_once '../model/payment_type_information_value.php';
$pay_type=$_POST['type'];
$val=$_POST['value'];
$payment_id=$_POST['pay_id'];



$arr=array($pay_type,$val,$payment_id);
$obj=new payment_type_information_value();
if($result=$obj->create($arr)){

    return $result;
}
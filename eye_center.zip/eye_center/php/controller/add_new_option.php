<?php

require_once '../model/product_type_info_option.php';
require_once '../model/product_type_info.php';
require_once '../model/product_type_info_value.php';

$PTIO = new product_type_info_option();
$tpio = new product_type_info();
$TPIOV = new product_type_info_value();

$new_data = $_POST['new_option_data'];
$old_data = $_POST['old_option_data'];

$old_product_type_id = $old_data[0];
$old_product_id = $old_data[1];


$new_product_type_id = $new_data[0];
$new_product_id = $new_data[1];

$data2;
$data3;
$data4;




for ($i = 2; $i < count($new_data); $i+=2) {

    //$tpio->getid($type_id, $option_id)
    $data2[0] = $new_data[$i];
    $result = $PTIO->create($data2);
    $result2 = $PTIO->get_last_ID();

    foreach ($result2 as $value) {
        if ($value['max(`id`)'] != NULL) {

            $data3[0] = $value['max(`id`)'];
            $data3[1] = $new_product_type_id;

            $result3 = $tpio->create($data3);

            $result4 = $tpio->get_last_ID();
            foreach ($result4 as $value) {

                if ($value['max(`id`)'] != NULL) {

                    $data4[0] = $value['max(`id`)'];
                    $data4[1] = $new_data[$i + 1];
                    $data4[2] = $new_product_id;
                    $result5 = $TPIOV->create($data4);
         
                }
            }
        }
    }
}

for ($i = 2; $i < count($old_data); $i+=2) {
    $data4[0] = $old_data[$i];

    $data4[1] = $old_product_type_id;

    $result6 = $tpio->getid($data4[1], $data4[0]);

    if (empty($result6)) {
        $result3 = $tpio->create($data4);
        $result4 = $tpio->get_last_ID();
        foreach ($result4 as $value) {

            if ($value['max(`id`)'] != NULL) {
                $data5[0] = $value['max(`id`)'];

                $data5[1] = $old_data[$i + 1];
                $data5[2] = $old_product_id;
                $result7 = $TPIOV->create($data5);

            }
        }
    } else {

        foreach ($result6 as $value) {

            $product_type_info_id = $value['option_id'];
        }
        $data5[0] = $product_type_info_id;

        $data5[1] = $old_data[$i + 1];
        $data5[2] = $old_product_id;
        $result7 = $TPIOV->create($data5);

    }
}
    
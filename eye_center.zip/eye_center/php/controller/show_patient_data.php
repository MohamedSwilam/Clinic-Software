<?php



require_once '../model/patient.php';

$p1 = new patient();

$userID = $_POST['userID'];
$result=$p1->DisplayPatientInfoForm($userID);

if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        echo   $value['name'] . "~" . $value['email'] . "~" . $value['telephone'] . "~" . $value['bithdate'] . "~" . $value['ismale'] . "~" . $value['user_id']. "~" .$value['address_id'];
    }
}
?>
<?php
require_once '../model/reservation_type.php';
$r_t= new reservation_type();
$data = array("test", "test");
$result=$r_t->read($data);
if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
            if ($i == count($result) - 1) {
                echo $value['id'] . "~" . $value['type'];
            } else {
                echo $value['id'] . "~" . $value['type'] . "~";
                $i++;
            }
        
    }
}

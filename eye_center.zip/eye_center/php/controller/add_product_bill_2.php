<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/13/18
 * Time: 9:21 PM
 */
require_once '../model/product_bill.php';
$product_id=$_POST['productId'];
$bill_id=$_POST['billId'];
$date=$_POST['dateId'];
$arr=array($product_id,$bill_id,$date);
$obj=new product_bill();
if($obj->create($arr)){

    echo true;

}
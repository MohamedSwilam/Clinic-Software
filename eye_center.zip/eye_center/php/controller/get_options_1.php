<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/9/18
 * Time: 10:47 PM
 */

require_once '../model/payment_options.php';
$id=$_POST['option_id'];
$option_obj = new payment_options();
$arr=array($id);
if($result=$option_obj->read($arr)){

    foreach ($result as $row){

        echo $row['id']."~".$row['name']."~";

    }

    print_r($result);


}

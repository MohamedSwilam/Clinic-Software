<?php

include_once '../model/reservation.php';

$r1 = new reservation();
$patientID = $_POST['patientID'];

$result = $r1->viewReservationData($patientID);

if (!empty($result)) {
    foreach ($result as $value) {
        echo $value['doctorName'] . "~" . $value['type'] . "~" . $value['date'] . "~" . $value['start'] . "~" . $value['end'] . "~" . $value['roomName'];
    }
}
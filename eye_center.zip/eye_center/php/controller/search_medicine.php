<?php
include_once '../model/medecine.php';

$m1 = new medecine();
$value = $_POST['value'];
$searchBy = $_POST['searchBy'];


$result = $m1->search($searchBy, $value);



if (!empty($result)) {

    foreach ($result as $value) {
        echo $value[0] . "~" . $value[1] . "~". $value[2] . "~";
    }

    }
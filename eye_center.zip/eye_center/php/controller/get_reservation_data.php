<?php

include_once '../model/reservation.php';

$r1 = new reservation();
$patientID = $_POST['patientID'];

$result = $r1->readAllReservationData($patientID);

if (!empty($result)) {
    foreach ($result as $value) {
        echo $value['patient_id'] . "~" . $value['type_id'] . "~" . $value['doctorID'] . "~" . $value['date'] . "~" . $value['start'] . "~" . $value['end'] . "~" . $value['durationID'] . "~" . $value['room_id'];
    }
}
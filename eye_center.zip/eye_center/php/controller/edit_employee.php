<?php

//require_once '../model/user.php';
require_once '../model/administrator.php';

//$u1 = new user();
$a1 = new administrator();

$type = $_POST['account'];
$name = $_POST['name'];
$mail = $_POST['email'];
$mobile = $_POST['mobile'];
$cityID = $_POST['city'];
$cityName = $_POST['newCity'];
$buildingNumber = $_POST['building'];
$streetName = $_POST['street'];
$stateID = $_POST['state'];
$address = array($cityID, $streetName, $buildingNumber, $cityName, $stateID);
$DOB = $_POST['DOB'];
$gender = $_POST['gender'];
$salary = $_POST['salary'];
$workDurations = $_POST['workDurations'];
$userID = $_POST['userID'];


if (empty($type) || empty($name) || empty($mail) || empty($mobile) || empty($cityID) || empty($buildingNumber) || empty($streetName) || empty($stateID) || empty($DOB)) {
    echo "Please fill all fields!";
} else if ($type != "1" && $type != "3" && empty($salary)) {
    echo "Please fill out salary field!";
} else if ($type != "1" && $type != "3" && preg_match('/[A-Za-z]/', $salary)) {
    echo 'Salary should not contain any characters!';
} else if (preg_match('/[0-9]/', $name)) {
    echo "Name should not contain any numeric value!";
} else if (!is_numeric($cityID) && empty($cityName)) {
    echo "Please, fill out city name in address section!";
} else {
    $data = array($type, $name, $mail, $address, $mobile, $DOB, $gender, $salary, $userID, $workDurations);
    $result = $a1->updateEmployee($data);
    echo $result;
}
<?php

include_once '../model/visit.php';

$v1 = new visit();

$searchBy = $_POST['searchBy'];
$value = $_POST['value'];

$data = array($searchBy, $value);
$r = $v1->read($data);

$resultSize = count($r);

for ($i = 0; $i < $resultSize; $i++) {
    if ($i == $resultSize - 1) {
        echo $r[$i]->reservation->patient->id . "~" . $r[$i]->reservation->patient->name . "~" . $r[$i]->reservation->type->type . "~" . $r[$i]->reservation->room->name . "~" . $r[$i]->status->id . "~" . $r[$i]->status->status . "~" . $r[$i]->reservation->id . "~" . $r[$i]->reservation->doctor_id;
    } else {
        echo $r[$i]->reservation->patient->id . "~" . $r[$i]->reservation->patient->name . "~" . $r[$i]->reservation->type->type . "~" . $r[$i]->reservation->room->name . "~" . $r[$i]->status->id . "~" . $r[$i]->status->status . "~" . $r[$i]->reservation->id . "~" . $r[$i]->reservation->doctor_id . "!^@";
    }
}
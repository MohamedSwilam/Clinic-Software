<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 6:00 PM
 */


require_once '../model/bill_payments.php';

$payment_id=$_POST['paymentId'];
$bill_id=$_POST['bill_id'];



$obj= new bill_payments();
$arr=array($payment_id,$bill_id);

if($obj->create($arr)){


    echo true;

}
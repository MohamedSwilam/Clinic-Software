<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once '../model/product_type.php';

$pt = new product_type();

$data = array("123", "123");
$result = $pt->read($data);

if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        
            if ($i == count($result) - 1) {
                echo $value['id'] . "~" . $value['name'];
            } else {
                echo $value['id'] . "~" . $value['name'] . "~";
                $i++;
            }
        
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 4/27/18
 * Time: 7:30 PM
 */


require_once "../model/bill_reserve_user.php";
$bill= new bill_reserve_user();
$id=$_POST['patientId'];

$arr=array($id);
if($result=$bill->read($arr)) {

foreach ($result as $row){

    echo $row[0];



}



}




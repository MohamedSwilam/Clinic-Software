<?php
require_once '../model/payment_type.php';
$paymentobj= new payment_type();

if($result=$paymentobj->read_all()){

    foreach ( $result as $row){


        echo $row['id']."~".$row['name']."~";



    }


}


?>


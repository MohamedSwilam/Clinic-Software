<?php
include_once '../model/reservation.php';
$r1 = new reservation();
$result = $r1->readReservedPatients();
if (!empty($result)) {
    foreach ($result as $value) {
        echo $value['patient_id'] . "~";
    }
}
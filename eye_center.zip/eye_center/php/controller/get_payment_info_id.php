<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 3:35 PM
 */
require_once '../model/payment_info_type.php';
$payment_method_id_=$_POST['payment_type_id'];
$payment_option=$_POST['option_id'];
$obj= new payment_info_type();
$arr=array($payment_method_id_,$payment_option);

if ($result=$obj->get_id($arr)){

        foreach ($result as $row){


         echo $row['id'];

        }





}
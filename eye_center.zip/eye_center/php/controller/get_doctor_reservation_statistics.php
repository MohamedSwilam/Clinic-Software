<?php

include_once '../model/reservation.php';

$r1 = new reservation();

$doctorID = $_POST['doctorID'];
$result = $r1->getDoctorReservationStatistics($doctorID);

if (!empty($result)) {
    foreach ($result as $value) {
        echo $value['totalReservations'] . "~" . $value['missedReservations'] . "~" . $value['todayReservations'] . "~" . $value['todayVisits'];
    }
}
<?php

include_once '../model/option.php';

$o1 = new option();
$optionID = $_POST['value'];

$result = $o1->get_child_options($optionID);

if (!empty($result)) {
    foreach ($result as $value) {
        echo $value['option'] . "~";
    }
}
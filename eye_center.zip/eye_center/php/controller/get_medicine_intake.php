<?php

include_once '../model/medecine.php';

$m1 = new medecine();

$medicineID = $_POST['medicineID'];
$userID = $_POST['userID'];

if (isset($_POST['patientID']) && !empty($_POST['patientID'])) {
    $patientID = $_POST['patientID'];
    $result = $m1->readMedicineIntake($patientID, $medicineID);
} else {
    $result = $m1->readMedicineIntake($userID, $medicineID);
}

echo $result;

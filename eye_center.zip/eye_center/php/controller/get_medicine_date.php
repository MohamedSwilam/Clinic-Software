<?php

include_once '../model/medecine.php';

$m1 = new medecine();
$result = $m1->readMedicineDate();
$i=0;
if (!empty($result)) {
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['id'] . "~" . $value['name'];
        } else {
            echo $value['id'] . "~" . $value['name'] . "~";
            $i++;
        }
    }
}

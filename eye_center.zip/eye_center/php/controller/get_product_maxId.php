<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/13/18
 * Time: 7:52 PM
 */
require_once '../model/product.php';

$product_obj=new product();


if($result=$product_obj->get_max_id()){


    foreach ($result as $row){


        echo $row['MAX(id)'];

    }


}
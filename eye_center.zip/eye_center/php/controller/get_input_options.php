<?php

include_once '../model/option.php';

$optionType = $_POST['typeID'];
$data = array($optionType);

$o1 = new option();
$result = $o1->read($data);

if (!empty($result)) {
    $counter = 0;
    foreach ($result as $value) {
        if ($counter == count($result) - 1) {
            echo $value['id'] . "~" . $value['option'];
        } else {
            echo $value['id'] . "~" . $value['option'] . "~";
        }
        $counter++;
    }
}
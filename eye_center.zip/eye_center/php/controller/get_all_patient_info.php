<?php

include_once '../model/patient.php';

$p1 = new patient();
$u1 = new address();
$patientID = $_POST['patientID'];

$result = $p1->getAllPatientData($patientID);
$aR = $u1->readFullAddress($patientID);
$fullAddress = $aR->buildingNumber . " " . $aR->street . " - " . $aR->city . " - " . $aR->state . " - " . $aR->country;
echo $result->id . "~" . $result->name . "~" . $result->birthdate . "~" . $result->ismale . "~" . $result->email->email . "~" . $result->telephone->telephone . "~" . $fullAddress;

<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/2/18
 * Time: 6:33 PM
 */

require_once '../model/bill_reserve_user.php';
require_once '../model/reservation_type.php';
$searchby=$_POST['searchBy'];
$val=$_POST['value'];

$data=array($searchby,$val);

$billobj =new bill_reserve_user();
$reservetype= new  reservation_type();
$arr=array();
if($result=$billobj->search($data)){

    foreach ($result as $row ){
        $type= $reservetype->get_type($row['reservation_id']);
        foreach ($type as $rows){
            array_push($arr,$rows[0]);

        }



    }

    $i=0;

    foreach ($result as $row ) {

        echo $row['id'] . '~' .
            $row['name'] . '~' . $arr[$i] . '~' . $row['date'] . '~'
            . $row['time'] . '~' . $row['paid'] . '~' . $row['total'] . '~' . $row['reservation_id']  . '!^@';

        $i++;

    }

}
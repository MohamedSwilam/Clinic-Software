<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


require '../model/product.php';

$P = new product();
$type_id = $_POST['type_id'];
$product_name = $_POST['product_name'];
$product_price = $_POST['product_price'];
$product_quantity = $_POST['product_quantity'];
$data[0] = $type_id;
$data[1] = $product_name;
$data[2] = $product_price;
$data[3] = $product_quantity;
$result = $P->create($data);
echo $result;



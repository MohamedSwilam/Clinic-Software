<?php

include_once '../model/option.php';

$optionID = $_POST['inputID'];

$o1 = new option();

$result = $o1->get_child_options($optionID);

if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['id'] . "~" . $value['option'];
        } else {
            echo $value['id'] . "~" . $value['option'] . "!^@";
            $i++;
        }
    }
}
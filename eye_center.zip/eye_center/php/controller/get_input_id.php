<?php

include_once '../model/option.php';

$optionName = $_POST['inputName'];
$optionType = $_POST['type'];

$o1 = new option();

$result = $o1->get_option_id($optionName, $optionType);

echo $result->id;


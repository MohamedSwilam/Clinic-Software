<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once '../model/product.php';
include_once '../model/product_type.php';

//$u1 = new user();
$p1 = new product();
$pt1 = new product_type();

$product_id=$_POST['product_id'];
$result = $p1->get_product_by_id($product_id);


if (!empty($result)) {

    foreach ($result as $value) {
        $product_type_ID = $value['type_id'];
        $result2 = $pt1->get_product_by_ID($product_type_ID);
        foreach ($result2 as $value2) {
                echo $value['id'] . "~" . $value['name'] . "~" . $value2['name'] . "~" . $value['type_id'];
          
        }
    }
}
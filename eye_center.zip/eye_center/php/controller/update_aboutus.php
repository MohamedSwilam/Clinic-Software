<?php
require_once "../model/html.php";

$h1 = new html();
$x=$_POST['text'];

$data = array($x);
$result=$h1->update_aboutus($data);
echo $x;
?>
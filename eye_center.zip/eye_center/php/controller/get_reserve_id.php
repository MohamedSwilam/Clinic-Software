<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/12/18
 * Time: 10:40 PM
 */
require_once '../model/reservation_type.php';
$obj=new reservation_type();
$id=$_POST['id'];
if ($result=$obj->get_res_id($id)){

foreach ($result as $row){


    echo $row['id'];

}



}
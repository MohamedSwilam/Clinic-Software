<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 3/11/18
 * Time: 7:56 PM
 */
require_once '../model/medecine.php';
$medecineObj= new medecine();
$data=array($_POST['id']);
$result= $medecineObj->read($data);
foreach ($result as $row){


    echo $row[0]."~".$row[1]."~";
}

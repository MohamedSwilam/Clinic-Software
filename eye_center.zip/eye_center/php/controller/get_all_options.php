<?php

require '../model/product_type_info_option.php';

$PTIO = new product_type_info_option();
$data[0] = 1;
$result = $PTIO->read($data);


if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['id'] . "~" . $value['name'];
        } else {
            echo $value['id'] . "~" . $value['name'] . "~";
            $i++;
        }
    }
}

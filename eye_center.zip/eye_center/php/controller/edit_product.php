<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once '../model/product.php';
require_once '../model/product_type.php';
require_once '../model/product_type_info_value.php';




$p = new product();

$ptiV = new product_type_info_value();

$product_id = $_POST['productID'];
$product_name = $_POST['product_name'];
$product_price = $_POST['product_price'];
$product_quantity = $_POST['product_quantity'];

$options_Vlaue_arr = $_POST['options_Vlaue_arr'];

$options_Vlaue_id_arr = $_POST['options_Vlaue_id_arr'];






$data[0] = $product_id;

$data[1] = $product_name;

$data[2] = $product_price;

$data[3] = $product_quantity;

$data[5] = $options_Vlaue_id_arr;

$data[4] = $options_Vlaue_arr;


$result = $p->update($data);


echo $result;


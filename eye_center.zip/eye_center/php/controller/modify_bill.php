<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/10/18
 * Time: 11:34 PM
 */

require_once '../model/bill.php';


$bill_Id=$_POST['bill_id'];
$paid=$_POST['paid'];
$total_paid=0;
$obj = new bill();
$arr=array($bill_Id);

if($result=$obj->read($arr)){

    foreach ($result as $row) {
        $total_paid +=$row['paid'];
    }

    $total_paid+=$paid;
    array_push($arr,$total_paid);



    if($obj->update($arr)){

        echo true;

    }

}


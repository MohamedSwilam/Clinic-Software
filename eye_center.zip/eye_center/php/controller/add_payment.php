<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 4:27 PM
 */
$pay_method=$_POST['id'];
$sub_by=$_POST['submitted_by'];
require_once '../model/payment.php';
$obj=new payment();

$array=array($pay_method,$sub_by);
if($obj->create($array)){

    if ($result=$obj->get_max_id()){

        foreach ($result as $row ){

            echo $row['MAX(id)'];



        }


    }

}
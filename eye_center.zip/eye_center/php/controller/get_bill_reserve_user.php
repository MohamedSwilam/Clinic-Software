<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/2/18
 * Time: 2:50 AM
 */
require_once '../model/bill_reserve_user.php';
require_once '../model/reservation_type.php';
$billobj =new bill_reserve_user();
$reservetype= new  reservation_type();
$arr=array();
if($result=$billobj->read_all()){

   foreach ($result as $row ){
      $type= $reservetype->get_type($row['reservation_id']);
    foreach ($type as $rows){
    array_push($arr,$rows[0]);

    }



    }

        $i=0;
    foreach ($result as $row ) {
        echo $row['id'] . '~' .
            $row['name'] . '~' . $arr[$i] . '~' . $row['date'] . '~'
            . $row['time'] . '~' . $row['paid'] . '~' . $row['total'] . '~' . $row['reservation_id']  . '!^@';

        $i++;

    }

}
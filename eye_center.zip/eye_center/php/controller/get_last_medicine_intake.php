<?php

include_once '../model/medecine.php';

$m1 = new medecine();

$result = $m1->getMaxID();

echo $result;
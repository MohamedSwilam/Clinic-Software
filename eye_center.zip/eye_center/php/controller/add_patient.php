<?php
include_once '../model/patient.php';
$a1 = new patient();

$name = $_POST['name'];
$mail = $_POST['mail'];
$mobile = $_POST['mobile'];
$DOB = $_POST['DOB'];
$gender = $_POST['gender'];
$cityID = $_POST['city'];
$cityName = $_POST['newCity'];
$buildingNumber = $_POST['building'];
$streetName = $_POST['street'];
$stateID = $_POST['state'];

if (empty($name) || empty($mail) || empty($mobile) || empty($cityID) || empty($buildingNumber) || empty($streetName) || empty($stateID) || empty($DOB)) {
    echo "Please fill all fields!";
} else if (preg_match('/[0-9]/', $name)) {
    echo "Name should not contain any numeric value!";
} else if (!is_numeric($cityID) && empty($cityName)) {
    echo "Please, fill out city name in address section!";
} else {
    $address = array($cityID, $streetName, $buildingNumber, $cityName, $stateID);
    $data = array($name, $mail, $mobile, $address, $DOB, $gender);
    $result = $a1->newPatient($data);
    echo $result;
}
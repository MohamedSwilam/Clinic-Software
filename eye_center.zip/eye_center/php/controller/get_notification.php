<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once '../model/notifications.php';
require_once '../model/notification_type.php';
require_once '../model/patient.php';


$n1 = new notifications();
$user = new patient();
$nt = new notification_type();
$userID = $_POST['UserID'];


$data[0] = $userID;

$result = $n1->read($data);

$result3 = $user->read($data);

if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        $type_id = $value['type_id'];


        $result2 = $nt->getNotificationByID($type_id);


        if (!empty($result2)) {

            foreach ($result2 as $value2) {

                if (!empty($result3)) {

                    foreach ($result3 as $value3) {


                        if ($i == count($result) - 1) {

                            echo $value['id'] . "~" . $value['user_id'] . "~" . $value2['name']." Notification" . "~" . $value2['message'] . "~" . $value['time'] . "~" . $value['status'];
                        } else {
                            echo $value['id'] . "~" . $value['user_id'] . "~" . $value2['name'] ." Notification" . "~" . $value2['message'] . "~" . $value['time'] . "~" . $value['status'] . "!^@";
                            $i++;
                        }
                    }
                }
            }
        }
    }
}
        
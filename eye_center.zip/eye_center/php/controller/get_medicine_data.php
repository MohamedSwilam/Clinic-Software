<?php

include_once '../model/medecine.php';

$m1 = new medecine();
$result = $m1->read_medicine_data();

if (!empty($result)) {
    $i = 0;

    foreach ($result as $value) {
        echo $value[0] . "~" . $value[1] . "~" . $value[2]."~";
    }
}
<?php

include_once '../model/reservation.php';

$r1 = new reservation();

$result = $r1->getReservationStatistics();

if (!empty($result)) {
    foreach ($result as $value) {
        echo $value['totalReservations'] . "~" . $value['missedReservations'] . "~" . $value['todayReservations'] . "~" . $value['todayVisits'];
    }
}
<?php
require_once '../model/medecine.php';
$medobj= new medecine();

$data=array($_POST['id']);
$result = $medobj->delete($data);
echo $result;
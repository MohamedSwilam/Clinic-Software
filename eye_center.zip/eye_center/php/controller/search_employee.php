<?php

//include_once '../model/user.php';
include_once '../model/administrator.php';

//$u1 = new user();
$a1 = new administrator();
$value = $_POST['value'];
$searchBy = $_POST['searchBy'];

$result = $a1->search($searchBy, $value);

if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['id'] . "~" . $value['name'] . "~" . $value['type'] . "~" . $value['email'] . "~" . $value['telephone'];
        } else {
            echo $value['id'] . "~" . $value['name'] . "~" . $value['type'] . "~" . $value['email'] . "~" . $value['telephone'] . "!^@";
            $i++;
        }
    }
}
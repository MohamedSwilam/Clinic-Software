<?php

include_once '../model/form_user_access.php';

$userID = $_POST['userID'];

$fuc = new form_user_access();
$data = array($userID);
$result = $fuc->read($data);

for ($i = 0; $i < count($result); $i++) {
    if ($i == count($result) - 1) {
        echo $result[$i]->id . "~" . $result[$i]->form_type->type;
    } else {
        echo $result[$i]->id . "~" . $result[$i]->form_type->type . "~";
    }
}
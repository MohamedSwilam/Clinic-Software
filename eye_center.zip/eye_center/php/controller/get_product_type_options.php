<?php

require '../model/product_type_info.php';
require '../model/product_type_info_option.php';

$PTI = new product_type_info();
$ptiO = new product_type_info_option();

$type_id=$_POST['typeID'];
$result1 = $PTI->get_All_type_options($type_id);
if (!empty($result1)) {
    foreach ($result1 as $value) {
        $result2 = $ptiO->get_option_by_id($value['option_id']);

        if (!empty($result2)) {
              $i = 0;
            
            foreach ($result2 as $value2) {
                
                if ($i == count($result1) - 1) {
                    echo $value2['id'] . "~" . $value2['name'];
                } else {
                    echo $value2['id'] . "~" . $value2['name'] . "~";
                    $i++;
                }
            }
        }
    }
}

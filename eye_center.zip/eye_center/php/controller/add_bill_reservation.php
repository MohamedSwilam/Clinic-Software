<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 4/29/18
 * Time: 8:09 PM
 */
include '../model/bill_reserve_user.php';
$bill_resrve_obj=new bill_reserve_user();
$bilId=$_POST['billId'];
$patientId=$_POST['patientId'];
$dateid=$_POST['dateId'];
$resid=$_POST['resid'];
$data=array($bilId,$patientId,$dateid,$resid);



if($result=$bill_resrve_obj->create($data)){

if ($result){echo true;}

}
<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 3/11/18
 * Time: 8:44 PM
 */
require_once "../model/category.php";
$categoryObj= new category();
$data=array($_POST['id']);
$result=$categoryObj->read($data);
foreach ($result as $row){
    echo  $row['name']."~";


}
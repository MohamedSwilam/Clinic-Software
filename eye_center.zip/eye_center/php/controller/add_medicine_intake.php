<?php

include_once '../model/medecine.php';

$m1 = new medecine();

$medicineID = $_POST['medicineID'];
$description = $_POST['description'];
$deal = $_POST['deal'];
$numberOfTimes = $_POST['numberOfTimes'];
$doseType = $_POST['doseType'];
$numberOfDoseIntakeDurations = $_POST['numberOfDoseIntakeDurations'];
$doseIntakeDurations = $_POST['doseIntakeDurations'];
$userID = $_POST['userID'];

if (empty($medicineID) || empty($deal) || empty($numberOfTimes)) {
    echo "Please fill all fields!";
} else if (preg_match('/[A-Za-z]/', $numberOfTimes)) {
    echo 'Number should not contain any characters!';
} else if (preg_match('/[A-Za-z]/', $doseType)) {
    echo 'Dose duration should be numeric! /n Please, Referesh The Page!';
} else {
    $validateIntakeDurations = TRUE;
    if ($numberOfDoseIntakeDurations != 0) {
        $counter = 0;
        for ($i = 0; $i < count($doseIntakeDurations); $i+=3) {
            if (empty($doseIntakeDurations[$i]) || empty($doseIntakeDurations[$i + 2])){
                echo "Please fill all fields!";
                break;
            }
        }
    }

    if ($validateIntakeDurations == TRUE) {
        $data = array($deal, $numberOfTimes, $doseType, $medicineID, $userID);
        $medicineIntakeID = $m1->addMedicineIntake($data);
        if (!empty($description) && $medicineIntakeID != FALSE) {
            $dataDescription = array($description, $medicineID, $userID);
            $result = $m1->addMedicineDescription($dataDescription);
        }

        if ($numberOfDoseIntakeDurations != 0 && $medicineIntakeID != FALSE) {
            for ($i = 0; $i < count($doseIntakeDurations); $i+=3) {
                $DoseDurationsData = array($doseIntakeDurations[$i], $doseIntakeDurations[$i + 2], $medicineIntakeID, $doseIntakeDurations[$i + 1]);
                $result = $m1->addMedicineIntakeDuration($DoseDurationsData);
                if ($result != 1) {
                    break;
                }
            }
        }
        echo $result;
    }
}
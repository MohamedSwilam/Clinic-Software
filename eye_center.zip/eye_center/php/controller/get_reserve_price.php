<?php

/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 4/29/18
 * Time: 6:43 PM
 */include_once '../model/reservation_type.php';
include_once '../model/extra_fees.php';
$resObj = new reservation_type();
$type = $_POST['id'];
$result = $resObj->reserve_price($type);


$extra = $_POST['extra'];

if ($extra > 0) {
    $extrafees = new extra_fees();
    $result = $extrafees->retback($type, $extra);
    echo $result;
} else {
    if ($result) {
        foreach ($result as $row) {
            echo $row['price'];
        }
    }
}
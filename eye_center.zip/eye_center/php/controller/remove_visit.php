<?php

include_once '../model/visit.php';

$reservationID = $_POST['reservationID'];

$v1 = new visit();

$data = array($reservationID);
$result = $v1->delete($data);
echo $result;
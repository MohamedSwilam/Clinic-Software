<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/9/18
 * Time: 10:32 PM
 */
require_once '../model/payment_info_type.php';
$obj= new payment_info_type();
$id=$_POST['id'];

$arr=array($id);
if($result=$obj->read($arr)){


    foreach ($result as $row){


        echo $row['option_id']."~";
    }



}
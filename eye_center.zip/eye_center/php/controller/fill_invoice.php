

<?php

/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/2/18
 * Time: 11:17 PM
 */
/*




  session_start();






  $_SESSION['head']=$_POST['head'];
  $_SESSION['body']=$_POST['body'];
  $_SESSION['split']=$_POST['split'];

  header("location:http://localhost/eye_center/fpdf/invoice_tem1.php");
 */




require_once '../../fpdf/invoice_tem.php';
$obj = new invoice($_POST['head'], $_POST['body'], $_POST['split']);
$result = $obj->ret();
echo $result;
?>

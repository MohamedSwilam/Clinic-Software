<?php

include_once '../model/form_code.php';

$fc = new form_code();

$formID = $_POST['formID'];
$data = array($formID);
$result = $fc->read($data);

echo $result;

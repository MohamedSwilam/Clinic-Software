<?php
require_once "../model/category.php";
$categoryobj= new category();
$catname=$_POST['catname'];
$data=array($catname);
$categoryobj->create($data);


?>
<?php

//include_once '../model/user.php';
include_once '../model/product.php';
include_once '../model/product_type_info_option.php';
include_once '../model/product_type_info_value.php';
include_once '../model/product_type_info.php';

//$u1 = new user();
$p1 = new product();
$pt1 = new product_type();


$data[0] = NULL;
$result = $p1->read($data);


if (!empty($result)) {


    $i = 0;
    foreach ($result as $value) {
        $product_type_ID = $value['type_id'];
        $result2 = $pt1->get_product_by_ID($product_type_ID);
        foreach ($result2 as $value2) {

            if ($i == count($result) - 1) {
                echo $value['id'] . "~" . $value['name'] . "~" . $value2['name'] . "~" . $value['type_id'];
            } else {
                echo $value['id'] . "~" . $value['name'] . "~" . $value2['name'] . "~" . $value['type_id'] . "!^@";
                $i++;
            }
        }
    }
}
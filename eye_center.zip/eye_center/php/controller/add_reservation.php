<?php

include_once '../model/reservation.php';
include_once '../model/duration.php';
include_once '../model/date.php';

$r1 = new reservation();
$da1 = new date();

$patientID = $_POST['patientID'];
$reservationTypeID = $_POST['reservationTypeID'];
$doctorID = $_POST['doctorID'];
$duration = $_POST['duration'];
$roomID = $_POST['roomID'];
$date = $duration[0];

$dataDate = array($date, '00:00:00');
$dateResult = $da1->read($dataDate);
if (!empty($dateResult)) {
    foreach ($dateResult as $value) {
        $dateID = $value['id'];
    }
} else {
    $dateIDResult = $da1->create($dataDate);
    if ($dateIDResult == 1) {
        $dateID = $da1->getMaxID();
    }
}
//echo $dateID;
if (count($duration) > 2) {
    $d1 = new duration();
    $result = $d1->addSingleDuration($duration);
    if ($result != 0) {
        if (!empty($result)) {
            foreach ($result as $value) {
                $durationID = $value['max(`id`)'];
            }
        }
    }
} else {
    $durationID = $duration[1];
}

$data = array($patientID, $doctorID, $reservationTypeID, $durationID, $dateID, $roomID, "1");

$result = $r1->create($data);
echo $result;
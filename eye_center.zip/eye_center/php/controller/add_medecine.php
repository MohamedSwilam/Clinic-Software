<?php
require_once '../model/medecine.php';
$medob=new medecine();

$cat=$_POST['category'];
$mname=$_POST['mname'];
$data=array($mname,$cat);

$result=$medob->create($data);


echo $result;

?>
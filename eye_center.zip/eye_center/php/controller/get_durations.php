<?php

require_once '../model/doctor.php';
$d1 = new doctor();

$doctorID=$_POST['doctorID'];
$result = $d1->getUserDuration($doctorID);
if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['id'] . "~" . $value['name'].": ".$value['start']." - ".$value['end'];
        } else {
            echo $value['id'] . "~" . $value['name'].": ".$value['start']." - ".$value['end'] . "~";
            $i++;
        }
    }
}else{
    echo "-";
}

<?php
require_once "../model/category.php";
$categoryObj= new category();
$result=$categoryObj->read_all();
if($result){

    $i=0;

    foreach ($result as $row){
        echo $row['id'] . "~" . $row['name']."~";


    }


}


?>


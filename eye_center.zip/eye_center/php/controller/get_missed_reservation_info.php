<?php

include_once '../model/reservation.php';

$r1 = new reservation();
$searchBy = $_POST['searchBy'];
$value = $_POST['value'];

$data = array($searchBy, $value);
$result = $r1->readMissedReservations($data);



if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
        if ($i == count($result) - 1) {
            echo $value['id'] . "~" . $value['name'] . "~" . $value['type'] . "~" . $value['date'] . "~" . $value['start'] . "-" . $value['end'] . "~" . $value['roomName'] . "~" . $value['doctorID'];
        } else {
            echo $value['id'] . "~" . $value['name'] . "~" . $value['type'] . "~" . $value['date'] . "~" . $value['start'] . "-" . $value['end'] . "~" . $value['roomName'] . "~" . $value['doctorID'] . "!^@";
            $i++;
        }
    }
}
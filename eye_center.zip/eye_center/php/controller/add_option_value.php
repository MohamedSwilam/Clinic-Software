<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once '../model/product_type_info_value.php';
require_once '../model/product_type_info.php';
$tpio = new product_type_info();
$TPIOV = new product_type_info_value();
//array(typeid , productid)
$data = $_POST['data'];


//array(optionValue , optionID)

$option_data = $_POST['option_data'];
echo "lllllllllllllllllllllll".count($option_data);


for ($i = 0; $i < count($option_data); $i+=2) {
    //$tpio->getid($type_id, $option_id)
    $result = $tpio->getid($data[0], $option_data[$i + 1]);
    echo $option_data[$i + 1];
    echo " dd" . $data[0] . "zzzzzzzzzzzzzzzzzzz" . $option_data[$i + 1] . "dddddd";
    if (!empty($result)) {
        foreach ($result as $value) {
            $product_type_info_id = $value['id'];

            echo " xxxxxxx" . $product_type_info_id . "xxxxxxxxxxxxxx";
        }
        $data2[0] = $product_type_info_id;

        $data2[1] = $option_data[$i];
        $data2[2] = $data[1];
        $result2 = $TPIOV->create($data2);
        echo 'feeeeeeeeeeeeeeeee_____________________________________________';
    } else {
        
        echo 'mafeeeeeeeeeeeeeeeeesh_____________________________________________';
        $data4[0] = $option_data[$i+1];

        $data4[1] = $data[0];
        $result3 = $tpio->create($data4);
        $result4 = $tpio->get_last_ID();
        foreach ($result4 as $value) {

            if ($value['max(`id`)'] != NULL) {
                $data5[0] = $value['max(`id`)'];

                $data5[1] = $option_data[$i + 1];
                $data5[2] = $option_data[$i];
                $result7 = $TPIOV->create($data5);
                
            }
        }
    }
}





/*
$tpio= new product_type_info();
$result=$tpio->getid($type_id, $option_id);

foreach ($result as $value)
{

$TPIOV= new product_type_info_value();
$TPIOV->create($data);

}
 
 */
<?php

require_once '../model/doctor.php';
$d= new doctor();

$result=$d->getalldoctor();
if (!empty($result)) {
    $i = 0;
    foreach ($result as $value) {
            if ($i == count($result) - 1) {
                echo $value['id'] . "~" . $value['name'];
            } else {
                echo $value['id'] . "~" . $value['name'] . "~";
                $i++;
            }
        
    }
}
?>


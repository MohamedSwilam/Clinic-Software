<?php
include_once '../model/bill.php';

$bill_object= new bill();

if ($result=$bill_object->get_maxId()){
    foreach ($result as $row){
        echo $row['MAX(id)'];
    }
}
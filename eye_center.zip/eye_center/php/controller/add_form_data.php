<?php

include_once '../model/form.php';
include_once '../model/date.php';
include_once '../model/form_medicine.php';
include_once '../model/form_value.php';

$f1 = new form();
$d1 = new date();

$inputNames = $_POST['inputNames'];
$values = $_POST['values'];
$userID = $_POST['userID'];
$patientID = $_POST['patientID'];
$formTypeID = $_POST['formID'];
$currentDate = $_POST['currentDate'];

$dateData = array($currentDate, date("h:i:sa"));
$dateResult = $d1->create($dateData);
if ($dateResult == 1) {
    $dateID = $d1->getMaxID();
    $data = array($formTypeID, $userID, $patientID, $dateID);
    $result = $f1->create($data);
    if ($result == 1) {
        $formID = $f1->getMaxID();
        if (isset($_POST['medicines']) && !empty($_POST['medicines'])) {
            $medicines = $_POST['medicines'];
            $fm = new form_medicine();
            for ($i = 0; $i < count($medicines); $i++) {
                if ($fm->checkIntakeIdAvailble($medicines[$i])) {
                    $dataMedicine = array($formID, $medicines[$i]);
                    $medicineResult = $fm->create($dataMedicine);
                }
            }
        }
        echo count($inputNames);
        if (!empty($values) && !empty($inputNames)) {
            $fv = new form_value();
            for ($i = 0; $i < count($values); $i++) {
                if ($fv->checkExistID($inputNames[$i])) {
                    $valueData = array($values[$i], $inputNames[$i], $formID);
                    $formDataResult = $fv->create($valueData);
                }
            }
        }
    } else {
        echo "Failed to submit report";
        print_r($data);
    }
} else {
    echo "Date and Time Error!";
}

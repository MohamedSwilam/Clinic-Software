<?php

/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/13/18
 * Time: 10:09 PM
 */
require_once'../model/bill_reserve_user.php';
require_once'../model/product_bill.php';


$bru = new bill_reserve_user();
$result = $bru->read_all();

$date_array;
$i = 0;
foreach ($result as $value) {
    $Resrvation_money[$i] = $value['total'];
    $resrvation_date_Array[$i] = $value['date'];
    $i++;
}

for ($x = 0; $x < count($Resrvation_money); $x++) {
    if ($x == count($resrvation_date_Array) - 1) {

        echo $Resrvation_money[$x] . "~" . $resrvation_date_Array[$x];
    } else {
        echo $Resrvation_money[$x] . "~" . $resrvation_date_Array[$x] . "@@@";
    }
}


echo "#";


$Pb = new product_bill();
$result2 = $Pb->readall();

$date_array;
$j = 0;
$product_date_Array = NULL;
if (!empty($result2)) {
    foreach ($result2 as $value2) {
        $product_money[$j] = $value2['paid'];
        $product_date_Array[$j] = $value2['date'];
        $j++;
    }
}

for ($z = 0; $z < count($product_date_Array); $z++) {
    if ($z == count($product_date_Array) - 1) {

        echo $product_money[$z] . "~" . $product_date_Array[$z];
    } else {
        echo $product_money[$z] . "~" . $product_date_Array[$z] . "@@@";
    }
}
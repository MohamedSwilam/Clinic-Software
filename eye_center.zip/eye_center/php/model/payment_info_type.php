<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/9/18
 * Time: 10:28 PM
 */
include_once 'database.php';
include_once 'crud.php';
class payment_info_type extends database implements crud
{

    public function create(array $data)
    {
        $sql="INSERT INTO `payment_type_information`(`option_id`, `payment_type_id`) VALUES ($data[1],$data[0])";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function read(array $data)
    {       $id=$data[0];
        $sql="SELECT `option_id`  FROM `payment_type_information` WHERE `payment_type_id`='$id'";
        $result = $this->dataQuery($sql);
        return $result;

    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }

    public function get_id(array  $data){

        $sql="SELECT id FROM `payment_type_information` WHERE  `option_id`=$data[1] AND `payment_type_id`=$data[0]";
        $result = $this->dataQuery($sql);
        return $result;

    }
}
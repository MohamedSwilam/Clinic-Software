<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'database.php';

class form_code implements crud {

    public $id;
    public $code;

    public function create(array $data) {
        $sql = 'INSERT INTO `form_code`(`code`) VALUES ("' . $data[0] . '")';
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        if ($result == 1) {
            $sql = "SELECT MAX(`id`) FROM `form_code`";
            $result = $d1->dataQuery($sql);
            if (!empty($result)) {
                foreach ($result as $value) {
                    return $value['MAX(`id`)'];
                }
            }
        }
        return FALSE;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        $this->id = $data[0];
        $sql="SELECT `code` FROM `form_code` INNER JOIN form_type ON form_code.id = form_type.code_id AND form_type.id = '$this->id'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $this->code = $value['code'];
            }
        }
        return $this->code;
    }

    public function update(array $data) {
        
    }

}

<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'form.php';
include_once 'medecine.php';

class form_value implements crud {

    public function create(array $data) {
        $sql = "INSERT INTO `form_value`( `value`, `option_id`, `form_id`) VALUES ('$data[0]','$data[1]','$data[2]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function checkExistID($id) {
        $sql = "SELECT max(`id`) FROM `option`";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function update(array $data) {
        
    }

//put your code here
}

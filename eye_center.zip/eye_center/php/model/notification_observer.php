<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of notification_observer
 *
 * @author Hossam
 */

require_once '../model/notifications.php';

class notification_observer  implements SplObserver {
    /**
     * @var User[]
     */
    

    /**
     * It is called by the Subject, usually by SplSubject::notify()
     *
     * @param \SplSubject $subject
     */
    
    public $type_id;
    public $notfication_type_id;
    public $notfication;

    public function __construct($doctorID,$type_id) {
        $this->id = $doctorID;
        $this->notfication_type_id=$type_id;
        $this->notfication = new notifications();
    }

    public function update(\SplSubject $subject) {
        $data[0] = $this->type_id;
        $data[1]=$this->notfication_type_id;
        $this->notfication->createForUserType($data);
    }

}

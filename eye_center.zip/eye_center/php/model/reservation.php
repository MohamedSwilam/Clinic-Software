<?php

require_once 'database.php';
require_once 'crud.php';
require_once 'patient.php';
require_once 'reservation_type.php';
require_once 'date.php';
require_once 'duration.php';
require_once 'room.php';

class reservation extends database implements crud {

    public $id;
    public $patient_id;
    public $doctor_id;
    public $type_id;
    public $type;
    public $duration_id;
    public $date_id;
    public $room_id;
    public $status;
    public $patient;
    public $date;
    public $duration;
    public $room;

    public function __construct() {
        $this->patient = new patient();
        $this->type = new reservation_type();
        $this->date = new date();
        $this->duration = new duration();
        $this->room = new room();
    }

    public function create(array $data) {
        $this->patient_id = $data[0];
        $this->doctor_id = $data[1];
        $this->type_id = $data[2];
        $this->duration_id = $data[3];
        $this->date_id = $data[4];
        $this->room_id = $data[5];
        $this->status = $data[6];
        $sql = "INSERT INTO `reservation`(`patient_id`, `doctor_id`, `type_id`, `duration_id`, `date_id`, `room_id`, `status`) VALUES ('$this->patient_id','$this->doctor_id','$this->type_id','$this->duration_id','$this->date_id','$this->room_id','$this->status')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        $this->patient_id = $data[0];
        $this->status = 1;
        $sql = "DELETE FROM `reservation` WHERE `patient_id`='$this->patient_id' AND `status`='$this->status'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function readReservedPatients() {
        $sql = "SELECT `patient_id` FROM `reservation` WHERE `status`='1'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function read(array $data) {
        $searchBy = $data[0];
        $value = $data[1];
        $sql = "SELECT user.id, user.name, reservation_type.type, date.date, duration.id as durationID, duration.start, duration.end, room.name as roomName, reservation.doctor_id as doctorID, reservation.id as reservationID FROM (((((reservation INNER JOIN user ON reservation.patient_id = user.id) INNER JOIN reservation_type ON reservation.type_id = reservation_type.id) INNER JOIN date ON date.id = reservation.date_id) INNER JOIN duration on duration.id = reservation.duration_id) INNER JOIN room on room.id = reservation.room_id) WHERE $searchBy LIKE '%$value%'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function readTodayReservations(array $data) {
        $searchBy = $data[0];
        $value = $data[1];
        $sql = "SELECT user.id, user.name, reservation_type.type, date.date, duration.id as durationID, duration.start, duration.end, room.name as roomName, reservation.doctor_id as doctorID, reservation.id as reservationID FROM (((((reservation INNER JOIN user ON reservation.patient_id = user.id) INNER JOIN reservation_type ON reservation.type_id = reservation_type.id) INNER JOIN date ON date.id = reservation.date_id) INNER JOIN duration on duration.id = reservation.duration_id) INNER JOIN room on room.id = reservation.room_id) WHERE $searchBy LIKE '%$value%' AND date.date = CURDATE()";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function readMissedReservations(array $data) {
        $searchBy = $data[0];
        $value = $data[1];
        $sql = "SELECT user.id, user.name, reservation_type.type, date.date, duration.id as durationID, duration.start, duration.end, room.name as roomName, reservation.doctor_id as doctorID FROM (((((reservation INNER JOIN user ON reservation.patient_id = user.id) INNER JOIN reservation_type ON reservation.type_id = reservation_type.id) INNER JOIN date ON date.id = reservation.date_id) INNER JOIN duration on duration.id = reservation.duration_id) INNER JOIN room on room.id = reservation.room_id) WHERE $searchBy LIKE '%$value%' AND date.date < CURDATE()";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function getReservationStatistics() {
        $sql = "SELECT  (SELECT COUNT(*) FROM reservation WHERE status='1') AS totalReservations,(SELECT COUNT(*) FROM reservation INNER JOIN date WHERE date.date<CURDATE() AND reservation.date_id = date.id  AND status='1') AS missedReservations, (SELECT COUNT(*) FROM reservation INNER JOIN date WHERE date.date = CURDATE() AND reservation.date_id = date.id) AS todayReservations, (SELECT COUNT(*) FROM ((visit INNER JOIN reservation ON visit.reservation_id = reservation.id)INNER JOIN date ON visit.date_id = date.id AND date.date = CURDATE())) AS todayVisits";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function getDoctorReservationStatistics($doctorID) {
        $sql = "SELECT  (SELECT COUNT(*) FROM reservation WHERE status='1' AND reservation.doctor_id='$doctorID') AS totalReservations,(SELECT COUNT(*) FROM reservation INNER JOIN date WHERE date.date<CURDATE() AND reservation.date_id = date.id  AND status='1' AND reservation.doctor_id='$doctorID') AS missedReservations, (SELECT COUNT(*) FROM reservation INNER JOIN date WHERE date.date = CURDATE() AND reservation.date_id = date.id AND reservation.doctor_id='$doctorID') AS todayReservations, (SELECT COUNT(*) FROM ((visit INNER JOIN reservation ON visit.reservation_id = reservation.id  AND reservation.doctor_id='$doctorID')INNER JOIN date ON visit.date_id = date.id AND date.date = CURDATE())) AS todayVisits";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function getDoctorID() {
        $d1 = new database();
        $sql = "SELECT * FROM `reservation`";
        $result = $d1->dataQuery($sql);
        return $result;
    }

    public function readAllReservationData($patientID) {
        $this->patient_id = $patientID;
        $sql = " SELECT reservation.patient_id, reservation.type_id, reservation.doctor_id as doctorID, date.date, duration.id as durationID, duration.start, duration.end, reservation.room_id FROM ((reservation INNER JOIN date ON date.id = reservation.date_id) INNER JOIN duration on duration.id = reservation.duration_id) WHERE `patient_id` = '$this->patient_id' AND `status`='1'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function viewReservationData($patientID) {
        $sql = "SELECT user.name AS doctorName, reservation_type.type, date.date, duration.start, duration.end, room.name as roomName FROM (((((reservation INNER JOIN user ON reservation.doctor_id = user.id) INNER JOIN reservation_type ON reservation.type_id = reservation_type.id) INNER JOIN date ON date.id = reservation.date_id) INNER JOIN duration on duration.id = reservation.duration_id) INNER JOIN room on room.id = reservation.room_id) WHERE reservation.patient_id = '$patientID' AND reservation.status='1'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        
    }

}

<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product_type_info_value
 *
 * @author Hossam
 */
require_once '../model/database.php';
require_once '../model/crud.php';


class product_type_info_value extends database implements crud {

    public function create(array $data) {
        $sql = "INSERT INTO `product_type_info_value`( `product_type_info_id`, `value`, `product_id`) VALUES ('$data[0]','$data[1]','$data[2]')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }

    public function get_value($product_info_id) {
        $sql = "SELECT * FROM `product_type_info_value` WHERE `product_type_info_id`='$product_info_id'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update_value(array $data) {
        
        $sql = "UPDATE `product_type_info_value` SET `value` = '$data[1]' WHERE `id` = '$data[0]'";
        $result = $this->booleanQuery($sql);
        return $result;
        
    }

}

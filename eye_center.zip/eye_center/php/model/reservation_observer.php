
<?php

require_once '../model/notifications.php';

class reservation_observer implements SplObserver {
    /**
     * @var User[]
     */

    /**
     * It is called by the Subject, usually by SplSubject::notify()
     *
     * @param \SplSubject $subject
     */
    public $id;
    public $notfication_type_id;
    public $notfication;

    public function __construct($doctorID,$type_id) {
        $this->id = $doctorID;
        $this->notfication_type_id=$type_id;
        $this->notfication = new notifications();
    }

    public function update(\SplSubject $subject) {
        $data[0] = $this->id;
        $data[1]=$this->notfication_type_id;
        $this->notfication->create($data);
    }

}

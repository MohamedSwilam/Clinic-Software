<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/13/18
 * Time: 12:59 PM
 */
require_once '../model/reservation_type.php';

class extra_fees extends reservation_type
{

    public $reservationtype;



    public function  retback($name,$price){



        $this->reservationtype=new reservation_type();

        $result= $this->reservationtype->reserve_price($name);
            foreach ( $result as $item) {
                return $item['price']+$price;
            }





    }





}
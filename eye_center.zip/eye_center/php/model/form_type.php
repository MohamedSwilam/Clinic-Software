<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'user.php';
include_once 'doctor.php';
include_once 'form_code.php';

class form_type implements crud {

    public $id;
    public $type;
    public $code;
    public $has_medicine;
    public $status;

    function __construct() {
        $this->code = new form_code();
    }

    public function create(array $data) {
        $sql = "INSERT INTO `form_type`(`type`, `code_id`, `has_medicine`, `status`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        if ($result == 1) {
            $sql = "SELECT MAX(`id`) FROM `form_type`";
            $result = $d1->dataQuery($sql);
            if (!empty($result)) {
                foreach ($result as $value) {
                    return $value['MAX(`id`)'];
                }
            }
        }
        return FALSE;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }

}

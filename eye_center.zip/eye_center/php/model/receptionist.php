<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of receptionist
 *
 * @author Hossam
 */
require_once 'user.php';
class receptionist extends user {
    
    
    function getallreceptionist() {
        $sql="SELECT `name`,`id` FROM `user` WHERE `type_id`='4'";
        $result = $this->dataQuery($sql);
        return $result;
    }
    //put your code here
}

<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product_type
 *
 * @author Hossam
 */

require_once  '../model/database.php';
require_once '../model/crud.php';

class product_type extends database implements crud{
    public function create(array $data) {
         $sql="INSERT INTO `product_type` (`name`) VALUES ('$data[0]')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        $sql="SELECT * FROM `product_type` WHERE 1";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        
    }
    
    
    public function get_product_by_ID($productID) {
        $sql="SELECT * FROM `product_type` WHERE `id`= '$productID'";
        $result = $this->dataQuery($sql);
        return $result;
    }
//put your code here
}

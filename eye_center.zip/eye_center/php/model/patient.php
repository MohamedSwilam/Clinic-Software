<?php

include_once 'user.php';
include_once 'email.php';
include_once 'telephone.php';
include_once 'address.php';

class patient extends user {

    public $email;
    public $telephone;
    public $address;

    function __construct() {
        $this->email = new email();
        $this->telephone = new telephone();
        $this->address = new address();
    }

    public function newPatient(array $data) {
        //name, email, mobile, address, dob, gender
        $result = $this->address->create($data[3]);
        if ($result != FALSE) {
            $user = array($data[0], $data[4], $data[5], $result, "6", "1");
            $result = $this->create($user);
            if ($result == 1) {
                $sql = "SELECT max(`id`), `name` FROM `user` WHERE `id`= (SELECT max(`id`) FROM `user` WHERE 1)";
                $result = $this->dataQuery($sql);
                if (!empty($result)) {
                    foreach ($result as $value) {
                        $userid = $value['max(`id`)'];
                    }
                    $email = array($userid, $data[1]);
                    $result = $this->email->create($email);
                    if ($result == 1) {
                        $telephone = array($userid, $data[2]);
                        $result = $this->telephone->create($telephone);
                    }
                }
            }
        }
        return $result;
    }

    public function updatePatinet(array $data) {
        // $data=array($id,$name,$mobile,$DOB,$gender,$address,$email);
        $result = $this->address->create($data[5]);
        if ($result != FALSE) {
            $user = array($data[0], $data[1], $data[3], $data[4], $result, '6', "1");
            $result = $this->update($user);
            if ($result == 1) {
                $email = array($data[0], $data[6]);
                $result = $this->email->update($email);
                if ($result == 1) {
                    $telephone = array($data[0], $data[2]);
                    $result = $this->telephone->update($telephone);
                }
            }
        }
        return $result;
    }

    public function DisplayPatientInfoForm($userID) {
        $sql = "SELECT * FROM user, email, telephone WHERE user.id='$userID' AND email.user_id='$userID' AND telephone.user_id='$userID'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function getAllPatientData($patientid) {
        $sql = "SELECT user.id, user.name, user.bithdate,user.ismale, email.email, telephone.telephone FROM ((user INNER JOIN email ON user.id = email.user_id) INNER JOIN telephone ON user.id = telephone.user_id) WHERE user.id = '$patientid'";
        $result = $this->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $this->id = $value['id'];
                $this->name = $value['name'];
                $this->birthdate = $value['bithdate'];
                $this->ismale = $value['ismale'];
                $this->email->email = $value['email'];
                $this->telephone->telephone = $value['telephone'];
            }
        }
        return $this;
    }

    public function patientTable() {
        $sql = "SELECT user.*, email.email, user_type.type, telephone.telephone FROM (((user INNER JOIN email ON user.id = email.user_id AND user.type_id='6') INNER JOIN user_type ON user.type_id = user_type.id) INNER JOIN telephone ON user.id = telephone.user_id)";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function searchPatient($searchBy, $value) {
        $sql = "SELECT user.*, email.email, user_type.type, telephone.telephone FROM (((user INNER JOIN email ON user.id = email.user_id AND user.$searchBy LIKE '%$value%' AND user.type_id='6') INNER JOIN user_type ON user.type_id = user_type.id) INNER JOIN telephone ON user.id = telephone.user_id)";
        $result = $this->dataQuery($sql);
        return $result;
    }

}

<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 5:58 PM
 */

include_once 'database.php';
include_once 'crud.php';
class bill_payments extends database implements crud
{

    public function create(array $data)
    {
        $data= new DateTime("NOW", new DateTimeZone('Africa/Cairo'));
        $time=$data->format('Y-m-d H:i:s');
        $sql="INSERT INTO `bill_payment`(`payment_id`, `bill_id` ,`date`) VALUES ('$data[0]','$data[1]','$time')";
        return $this->booleanQuery($sql);

    }

    public function read(array $data)
    {
        // TODO: Implement read() method.
    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }



}
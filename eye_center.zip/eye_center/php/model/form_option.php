<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'option.php';
include_once 'form_type.php';

class form_option implements crud {

    public $id;
    public $option;
    public $form_type;

    function __construct() {
        $this->option = new option();
        $this->form_type = new form_type();
    }

    public function create(array $data) {
        $sql = "INSERT INTO `form_option`(`option_id`, `form_type_id`, `is_required`) VALUES ('$data[0]','$data[1]','$data[2]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }

//put your code here
}

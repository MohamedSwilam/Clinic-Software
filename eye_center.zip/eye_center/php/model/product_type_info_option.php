<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product_type_info_option
 *
 * @author Hossam
 */

include_once 'database.php';
include_once 'crud.php';

class product_type_info_option extends database implements crud  {
    public function create(array $data) {
         $sql="INSERT INTO `product_type_info_option`(`name`) VALUES ('$data[0]')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
         $sql="SELECT * FROM `product_type_info_option` WHERE 1 ";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        
    }
    
    public function get_option_by_id($option_id)
    {
        $sql="SELECT * FROM `product_type_info_option` WHERE `id`='$option_id'";
        $result = $this->dataQuery($sql);
        return $result;
        
    }
    public function get_last_ID()
    {
        $sql="SELECT max(`id`) FROM `product_type_info_option` WHERE 1 ";
        $result = $this->dataQuery($sql);
        return $result;
    }

//put your code here
}

<?php

require_once 'database.php';
require_once 'crud.php';

class visit_status extends database implements crud {
    public $id;
    public $status;

    public function create(array $data) {
        
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }

//put your code here
}

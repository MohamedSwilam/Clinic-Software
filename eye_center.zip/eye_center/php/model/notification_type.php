

<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of notifications
 *
 * @author Hossam
 */

require_once '../model/database.php';
require_once '../model/crud.php';
class notification_type extends database implements crud {

    public function create(array $data) {
        $sql = "INSERT INTO `notifications_type`(`user_id`, `type_id`, `status`) VALUES ('$data[0]','1','0')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }
    
    public function getNotificationByID($type_id)
    {
        $sql = "SELECT * FROM `notifications_type` WHERE `id` ='$type_id'";
        $result = $this->dataQuery($sql);
        return $result;
    }


//put your code here
}


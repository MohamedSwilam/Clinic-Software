<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'form.php';
include_once 'medecine.php';

class form_medicine implements crud {

    public $id;
    public $form_id;
    public $medicine;

    function __construct() {
        $this->form_id = new form();
        $this->medicine = new medecine();
    }

    public function create(array $data) {
        $sql = "INSERT INTO `form_medicine`( `form_id`, `medicine_intake_id`) VALUES ('$data[0]','$data[1]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function checkIntakeIdAvailble($id) {
        $sql = "SELECT `id` FROM `medicine_intake` WHERE `id`='$id'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }

//put your code here
}

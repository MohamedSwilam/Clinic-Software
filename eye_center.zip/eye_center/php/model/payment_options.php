<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/9/18
 * Time: 10:44 PM
 */
include_once 'database.php';
include_once 'crud.php';
class payment_options extends database implements crud
{

    public function create(array $data)
    {
        // TODO: Implement create() method.
    }

    public function read(array $data)
    {       $id=$data[0];
       $sql="SELECT `id`, `name` FROM `payment_type_information_option` WHERE id='$id'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }
}
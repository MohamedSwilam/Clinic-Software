<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product
 *
 * @author Hossam
 */
require '../model/database.php';
require '../model/crud.php';
require_once '../model/product_type_info_value.php';

class product extends database implements crud {

    public $ptiV;

    public function create(array $data) {

        $sql = "INSERT INTO `product`(`type_id`, `name` ,`price`, `quantity`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {

        $sql = "DELETE FROM `product` WHERE `id`='$data[0]'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function read(array $data) {
        $sql = "SELECT * FROM `product` WHERE 1";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        $this->ptiV = new product_type_info_value();
        $sql = "UPDATE `product` SET `name`='$data[1]' ,`price`='$data[2]',`quantity`='$data[3]' WHERE `id`='$data[0]'";
        $result = $this->booleanQuery($sql);
        for ($i = 0; $i < count($data[2]); $i++) {
            $data2[0] = $data[4][$i];
            $data2[1] = $data[5][$i];
            $result2 = $this->ptiV->update_value($data2);
        }
        echo $result2;
    }

    public function get_product_by_typeid($type_id) {
        $sql = "SELECT * FROM `product` WHERE `type_id`='$type_id'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function get_product_by_id($product_id) {
        $sql = "SELECT * FROM `product` WHERE `id`='$product_id'";
        $result = $this->dataQuery($sql);
        return $result;
    }
    public function  get_max_id(){


        $sql="SELECT MAX(id)FROM product";

        $result = $this->dataQuery($sql);
        return $result;

    }

//put your code here
}

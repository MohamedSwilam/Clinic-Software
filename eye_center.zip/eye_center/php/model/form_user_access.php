<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'doctor.php';
include_once 'form_type.php';

class form_user_access implements crud {

    public $id;
    public $user;
    public $form_type;

    function __construct() {
        $this->user = new doctor();
        $this->form_type = new form_type();
    }

    public function create(array $data) {
        $sql = "INSERT INTO `form_user_access`(`user_id`, `form_type_id`) VALUES ('$data[0]','$data[1]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        $sql = "SELECT  form_user_access.form_type_id, form_type.type FROM `form_user_access` INNER JOIN form_type ON form_user_access.user_id='$data[0]' AND form_user_access.form_type_id = form_type.id";
        $d1 = new database();
        $form = array();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $fua = new form_user_access();
                $fua->id = $value['form_type_id'];
                $fua->form_type->type = $value['type'];
                array_push($form, $fua);
            }
        }
        return $form;
    }

    public function update(array $data) {
        
    }

//put your code here
}

<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/13/18
 * Time: 9:18 PM
 */
require_once 'database.php';
require_once 'crud.php';
class product_bill extends database implements crud
{

    public function create(array $data)
    {   $product_id=$data[0];
        $bill_id=$data[1];
        $date_id=$data[2];
        echo "mostafa".$data[0]."/".$data[1]."/".$data[2];
       $sql="INSERT INTO `product_bills`(`product_id`, `bill_id`, `date_id`) VALUES ('$product_id','$bill_id','$date_id')";
        return  $this->booleanQuery($sql);

    }

    public function read(array $data)
    {
        // TODO: Implement read() method.
    }
    public function readall()
    {
$sql="SELECT product.name, bill.paid,date.date FROM product_bills INNER JOIN product on product.id=product_bills.product_id INNER JOIN bill ON bill.id=product_bills.bill_id INNER JOIN date ON date.id=product_bills.date_id";
        $result= $this->dataQuery($sql);

        return $result;

    }


    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }
}
<?php

include_once 'database.php';
include_once 'crud.php';
include_once 'user.php';
include_once 'doctor.php';
include_once 'patient.php';
include_once 'form_type.php';

class form implements crud {

    public $id;
    public $type;
    public $user;
    public $patient;

    function __construct() {
        $this->user = new doctor();
        $this->patient = new patient();
        $this->type = new form_type();
    }

    public function create(array $data) {
        $sql = "INSERT INTO `form`(`type_id`, `user_id`, `patient_id`, `date_id`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        return $result;
    }

    public function getMaxID() {
        $sql = "SELECT max(`id`) FROM `form`";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $result = $value['max(`id`)'];
            }
        }
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }

}

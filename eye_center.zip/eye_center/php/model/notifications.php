<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of notifications
 *
 * @author Hossam
 */
require_once '../model/database.php';
require_once '../model/crud.php';
require_once '../model/receptionist.php';

class notifications extends database implements crud {

    public function createForUserType(array $data) {
        $R = new receptionist();
        $result2 = $R->getallreceptionist();
        if (!empty($result2)) {
            foreach ($result2 as $value2) {
                $userID = $value2['id'];
                $date = new DateTime("now", new DateTimeZone('Africa/Cairo'));
                $time = $date->format('Y-m-d H:i:s');
                $sql = "INSERT INTO `notifications`(`user_id`, `type_id`, `status`,`time`) VALUES ('$userID','$data[1]','0','$time')";
                $result = $this->booleanQuery($sql);
                return $result;
            }
        }
    }

    public function create(array $data) {

        $date = new DateTime("now", new DateTimeZone('Africa/Cairo'));
        $time = $date->format('Y-m-d H:i:s');
        $sql = "INSERT INTO `notifications`(`user_id`, `type_id`, `status`,`time`) VALUES ('$data[0]','$data[1]','0','$time')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        $sql = "SELECT * FROM `notifications` WHERE `user_id`='$data[0]' ORDER BY `notifications`.`time` DESC limit 4";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        
    }

    public function editStatus($id) {
        $sql = "UPDATE `notifications` SET `status`= '1' WHERE `id`='$id'";

        $result = $this->booleanQuery($sql);
        return $result;
    }

//put your code here
}

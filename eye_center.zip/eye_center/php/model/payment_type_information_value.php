<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 4:55 PM
 */

include_once 'database.php';
include_once 'crud.php';
class payment_type_information_value extends database implements crud
{

    public function create(array $data)
    {
       $sql="INSERT INTO `payment_type_information_value`( `payment_type_information_id`, `value`, `payment_id`) VALUES ('$data[0]','$data[1]','$data[2]')";

            $result=$this->booleanQuery($sql);
            return $result;
    }

    public function read(array $data)
    {
        // TODO: Implement read() method.
    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }
}
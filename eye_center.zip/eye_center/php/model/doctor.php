<?php

include_once 'user.php';

class doctor extends user {
   
    function getalldoctor() {
        $sql="SELECT `name`,`id` FROM `user` WHERE `type_id`='2'";
        $result = $this->dataQuery($sql);
        return $result;
    }
    
    function getUserDuration($doctorID){
        $sql="SELECT duration.*, day.name FROM user INNER JOIN user_work_duration on user.id=user_work_duration.user_id and user.id='$doctorID' INNER JOIN duration on duration.id= user_work_duration.duration_id INNER JOIN day on duration.day_id =day.id";
        $result = $this->dataQuery($sql);
        return $result;
    }
    
}

<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product_type_info
 *
 * @author Hossam
 * 
 */

include_once 'database.php';
include_once 'crud.php';

class product_type_info extends database implements crud {
    public function create(array $data) {
        
        $sql="INSERT INTO `product_type_info`(`option_id`, `type_id`) VALUES ('$data[0]','$data[1]')";
        $result = $this->booleanQuery($sql);
        return $result;
        
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        
    }

    public function update(array $data) {
        
    }
    //SELECT  `name` FROM `product_type_info_option` WHERE `id`=1
    public function get_All_type_options($type_id)
    {
        $sql="SELECT *  FROM `product_type_info` WHERE `type_id`='$type_id'";
        $result = $this->dataQuery($sql);
        return $result;
    }
    
    public function getid($type_id,$option_id)
    {
        $sql="SELECT *  FROM `product_type_info` WHERE `type_id`='$type_id' AND `option_id`='$option_id'";
        $result = $this->dataQuery($sql);
        return $result;
    }
    
     public function get_last_ID()
    {
        $sql="SELECT max(`id`) FROM `product_type_info` WHERE 1 ";
        $result = $this->dataQuery($sql);
        return $result;
    }
//put your code here
}

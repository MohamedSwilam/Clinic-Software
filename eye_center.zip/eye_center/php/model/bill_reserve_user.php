<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 4/27/18
 * Time: 7:11 PM
 */


include_once 'database.php';
include_once 'crud.php';

class bill_reserve_user extends  database implements crud
{

    public function create(array $data)
    {
        $sql="INSERT INTO `bill_reserve_user`(`bill_id`, `patient_id`, `reservation_id`, `date_id`) VALUES ('$data[0]','$data[1]','$data[3]','$data[2]')";

        if ($result = $this->booleanQuery($sql)) {
            return true;
        }
        return false;

    }

    public function read(array $data)
    {
        $sql="SELECT  bill_id FROM bill_reserve_user WHERE patient_id= '$data[0]'";
        $result= $this->datafetch($sql);

        return $result;


    }
    public function read_all(){

        $sql="SELECT bill_reserve_user.reservation_id,user.id,user.name,date.date,date.time, bill.id,bill.paid,bill.total FROM bill_reserve_user INNER JOIN user ON user.id=bill_reserve_user.patient_id INNER JOIN date on date.id=bill_reserve_user.date_id INNER JOIN bill on bill.id=bill_reserve_user.bill_id ";
        $result= $this->dataQuery($sql);

        return $result;



    }public function search_billid($id){

        $sql="SELECT bill_reserve_user.reservation_id,user.id,user.name,date.date,date.time, bill.id,bill.paid,bill.total FROM bill_reserve_user INNER JOIN user ON user.id=bill_reserve_user.patient_id INNER JOIN date on date.id=bill_reserve_user.date_id INNER JOIN bill on bill.id=bill_reserve_user.bill_id WHERE bill_reserve_user.bill_id='$id'";
    $result= $this->dataQuery($sql);

    return $result;



}

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }

    public function search(array $data){

        $searchby=$data[0];
        $val=$data[1];

        $sql="SELECT bill_reserve_user.reservation_id,user.id,user.name,date.date,date.time, bill.id,bill.paid,bill.total FROM bill_reserve_user INNER JOIN user ON user.id=bill_reserve_user.patient_id INNER JOIN date on date.id=bill_reserve_user.date_id INNER JOIN bill on bill.id=bill_reserve_user.bill_id WHERE $searchby LIKE '%$val%'";
        $result= $this->dataQuery($sql);

        return $result;


    }
}
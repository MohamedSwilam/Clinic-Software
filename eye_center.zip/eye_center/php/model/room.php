<?php

include_once 'database.php';
include_once 'crud.php';

class room extends database implements crud {

    public $id;
    public $type_id;
    public $name;

    public function create(array $data) {
        $this->name = $data[0];
        $this->type_id = $data[1];
        $sql = "INSERT INTO `room`(`name`, `type_id`) VALUES ('$this->name','$this->type_id')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        $sql = "DELETE FROM `room` WHERE `id`='$data[0]'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function read(array $data) {
        $sql = "SELECT room.id, room.name, room_type.type_name FROM `room` INNER JOIN `room_type` WHERE room.type_id = room_type.id";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function search($searchBy, $value) {
        if ($searchBy == "name") {
            $searchBy = "room.name";
        }else{
            $searchBy = "room_type.type_name";
        }
        $sql = "SELECT room.id, room.name, room_type.type_name FROM `room` INNER JOIN `room_type` WHERE room.type_id = room_type.id AND $searchBy LIKE '%$value%'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function readRoomInfo($roomID) {
        $sql = "SELECT `name`, `type_id` FROM `room` WHERE `id`='$roomID'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        $sql = "UPDATE `room` SET `name`='$data[0]',`type_id`='$data[1]' WHERE `id`='$data[2]'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

}

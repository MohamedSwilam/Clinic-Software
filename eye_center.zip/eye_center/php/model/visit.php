<?php

require_once 'database.php';
require_once 'crud.php';
require_once 'reservation.php';
require_once 'date.php';
require_once 'patient.php';
require_once 'visit_status.php';

class visit implements crud, SplSubject {

    public $id;
    public $reservation;
    public $date;
    public $status;
    public $observers;

    public function __construct() {
        $this->reservation = new reservation();
        $this->date = new date();
        $this->status = new visit_status();
        $this->observers = new \SplObjectStorage();
    }

    public function create(array $data) {
        $database = new database();
        $dateInfo = array($data[1], $data[2]);
        $dateResult = $this->date->read($dateInfo);
        if (empty($dateResult)) {
            $this->date->create($dateInfo);
        }
        $dateID = $this->date->getMaxID();
        $sql = "INSERT INTO `visit`(`reservation_id`, `date_id`, `status`) VALUES ('$data[0]','$dateID','1')";
        $result = $database->booleanQuery($sql);
        return $result;
    }

    public function delete(array $data) {
        //visitID
        $database = new database();
        $sql = "DELETE FROM `visit` WHERE `reservation_id`='$data[0]'";
        $result = $database->booleanQuery($sql);
        return $result;
    }

    public function read(array $data) {
        $searchBy = $data[0];
        $value = $data[1];
        $reservationInfo = array();
        $database = new database();
        $sql = "SELECT visit.id AS visitID, visit.reservation_id, visit.date_id, visit.status AS statusID, visit_status.status AS statusName FROM ((visit INNER JOIN visit_status ON visit.status = visit_status.id) INNER JOIN date ON visit.date_id = date.id AND date.date = CURDATE()) ORDER BY visit.id ASC";
        $result = $database->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $v1 = new visit();
                $reservationID = $value['reservation_id'];
                $v1->reservation->id = $reservationID;
                $v1->status->id = $value['statusID'];
                $v1->status->status = $value['statusName'];
                $sql = "SELECT user.id, user.name, reservation_type.type, date.date, duration.id as durationID, duration.start, duration.end, room.name as roomName, reservation.doctor_id as doctorID FROM (((((reservation INNER JOIN user ON reservation.patient_id = user.id) INNER JOIN reservation_type ON reservation.type_id = reservation_type.id) INNER JOIN date ON date.id = reservation.date_id) INNER JOIN duration on duration.id = reservation.duration_id) INNER JOIN room on room.id = reservation.room_id) WHERE reservation.id = '$reservationID'";
                $result2 = $database->dataQuery($sql);
                if (!empty($result2)) {
                    foreach ($result2 as $value2) {
                        $v1->reservation->patient->id = $value2['id'];
                        $v1->reservation->patient->name = $value2['name'];
                        $v1->reservation->type->type = $value2['type'];
                        $v1->reservation->date->date = $value2['date'];
                        $v1->reservation->duration->id = $value2['durationID'];
                        $v1->reservation->duration->from = $value2['start'];
                        $v1->reservation->duration->to = $value2['end'];
                        $v1->reservation->room->name = $value2['roomName'];
                        $v1->reservation->doctor_id = $value2['doctorID'];
                        array_push($reservationInfo, $v1);
                    }
                }
            }
        }
        return $reservationInfo;
    }

    public function update(array $data) {

        $database = new database();
        $sql = "UPDATE `visit` SET `status`= '$data[0]' WHERE `reservation_id`='$data[1]'";
        $result = $database->booleanQuery($sql);
        return $result;
    }

    public function getVisitedReservationsIDs() {
        $database = new database();
        $sql = "SELECT `reservation_id` FROM `visit`";
        $result = $database->dataQuery($sql);
        return $result;
    }

    public function attach(\SplObserver $observer) {

        $this->observers->attach($observer);
    }

    public function detach(\SplObserver $observer) {
        $this->observers->detach($observer);
    }

    public function notify() {
        foreach ($this->observers as $observer) {
            $observer->update($this);
        }
    }

}
<?php
include_once 'database.php';
include_once 'crud.php';

class category extends database implements crud{


    public function create(array $data)
    {
        $sql="INSERT INTO `medicine_category`(`name`) VALUES ('$data[0]')";

         if($result = $this->booleanQuery($sql)){return true;}
        return false;
    }

    public function read(array $data)
    {
        $sql="SELECT  `name` FROM `medicine_category` WHERE id='$data[0]'";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }public function read_all(){


    $sql="SELECT * FROM `medicine_category` ";
    $result = $this->dataQuery($sql);
    return $result;
}
}
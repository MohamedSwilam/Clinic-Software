<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 4/29/18
 * Time: 7:04 PM
 */

require_once 'database.php';
require_once 'crud.php';



class bill extends database implements crud
{

    public function create(array $data)
    {
        $sql="INSERT INTO `bill`(`total`) VALUES ($data[0])";
        if ($result = $this->booleanQuery($sql)) {
            return true;
        }
        return false;
    }

    public function read(array $data)
    {
        $id=$data[0];
        $sql="SELECT `paid` FROM `bill` WHERE `id`=$id";
        $result= $this->dataQuery($sql);

        return $result;

        // TODO: Implement read() method.
    }

    public function update(array $data)
    {$id=$data[0];
        $amount=$data[1];
        $sql="UPDATE `bill` SET `paid`=$amount WHERE id='$id'";
        $result = $this->booleanQuery($sql);
        return $result;

    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }
    public function get_maxId(){

        $sql="SELECT MAX(id) FROM bill";
        $result = $this->dataQuery($sql);
        return $result;


    }



    public function add_product_bill(array $data){
        $paid=$data[0];
        $total=$data[1];
        $is_in=$data[2];

        $sql="INSERT INTO `bill`(`paid`, `total`, `is_in`) VALUES ($paid,$total,$is_in)";

        if ($result = $this->booleanQuery($sql)) {
            return true;
        }
        return false;
    }


}
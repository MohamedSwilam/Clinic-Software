<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/9/18
 * Time: 9:28 PM
 */
include_once 'database.php';
include_once 'crud.php';

class payment_type extends database implements crud
{

    public function create(array $data)
    {
        // TODO: Implement create() method.
    }

    public function read(array $data)
    {
        // TODO: Implement read() method.
    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }

    public function read_all(){


        $sql="SELECT * FROM `payment_type` WHERE 1";
        $result = $this->dataQuery($sql);
        return $result;




    }
}
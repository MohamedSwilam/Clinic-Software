<?php

include_once 'database.php';
include_once 'crud.php';

class option implements crud {

    public $id;
    public $option;
    public $typeID;

    public function create(array $data) {
        $sql = "INSERT INTO `option`( `option`, `type_id`, `parent_id`) VALUES ('$data[0]','$data[1]','$data[2]')";
        $d1 = new database();
        $result = $d1->booleanQuery($sql);
        if ($result == 1) {
            $sql = "SELECT MAX(`id`) FROM `option`";
            $result = $d1->dataQuery($sql);
            if (!empty($result)) {
                foreach ($result as $value) {
                    return $value['MAX(`id`)'];
                }
            }
        }
        return FALSE;
    }

    public function delete(array $data) {
        
    }

    public function read(array $data) {
        $sql = "SELECT `id`, `option` FROM `option` WHERE `type_id`='$data[0]'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        return $result;
    }

    public function get_option_id($optionName, $optionType) {
        $sql = "SELECT `id` FROM `option` WHERE `option`='$optionName' AND `type_id`='$optionType'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $this->id = $value['id'];
            }
        }
        return $this;
    }

    public function checkIdAvailable($id, $typeID) {
        $sql = "SELECT `id` FROM `option` WHERE `id`='$id' AND `type_id`='$typeID'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $id = $value['id'];
                return $id;
            }
        }
        return FALSE;
    }

    public function checkOptionAvailable($optionName, $typeID) {
        $sql = "SELECT `id` FROM `option` WHERE `option`='$optionName' AND `type_id`='$typeID'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $id = $value['id'];
                return $id;
            }
        }
        return FALSE;
    }

    public function get_child_options($optionID) {
        $sql = "SELECT `id`, `option` FROM `option` WHERE `parent_id`='$optionID'";
        $d1 = new database();
        $result = $d1->dataQuery($sql);
        return $result;
    }

    public function update(array $data) {
        
    }

//put your code here
}

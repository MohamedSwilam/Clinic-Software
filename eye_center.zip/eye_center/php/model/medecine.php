<?php

include_once 'database.php';
include_once 'crud.php';

class medecine extends database implements crud {

    public function create(array $data) {
        $sql = "INSERT INTO `medicine`(`name`,`category_id`) VALUES ('$data[0]','$data[1]')";
        if ($result = $this->booleanQuery($sql)) {
            return true;
        }
        return false;
    }

    public function addMedicineIntake(array $data) {
        $sql = "INSERT INTO `medicine_intake`(`date_id`, `number`, `each/times`, `medicine_id`, `user_id`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]')";
        $result = $this->booleanQuery($sql);
        if ($result == 1) {
            $sql = "SELECT max(`id`) FROM `medicine_intake`";
            $result = $this->dataQuery($sql);
            if (!empty($result)) {
                foreach ($result as $value) {
                    $medicineIntakeID = $value['max(`id`)'];
                }
                return $medicineIntakeID;
            } else {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    public function addMedicineDescription(array $data) {
        $sql = "INSERT INTO `medicine_description`(`value`, `medicine_id`, `user_id`) VALUES ('$data[0]','$data[1]','$data[2]')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function addMedicineIntakeDuration(array $data) {
        $sql = "INSERT INTO `medicine_intake_duration`(`duration_id`, `hrs`, `intake_id`, `after/before`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]')";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function read(array $data) {
        $sql = "SELECT `name`, `category_id` FROM `medicine` WHERE id ='$data[0]'";
        $result = $this->datafetch($sql);
        return $result;
    }

    public function readAllMedicine() {
        $sql = "SELECT * FROM `medicine`";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function readMedicineDate() {
        $sql = "SELECT * FROM `medicine_date`";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function readMedicineDuration() {
        $sql = "SELECT * FROM `medicine_duration`";
        $result = $this->dataQuery($sql);
        return $result;
    }

    public function deleteMedicineDescription($userID, $medicineID) {
        $sql = "DELETE FROM `medicine_description` WHERE `user_id`='$userID' AND `medicine_id`='$medicineID'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function deleteMedicineIntake($userID, $medicineID) {
        $sql = "DELETE FROM `medicine_intake` WHERE `medicine_id`='$medicineID' AND `user_id`='$userID'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function readMedicineIntake($userID, $medicineID) {
        $sql = "SELECT * FROM `medicine_intake` WHERE `medicine_id`='$medicineID' AND `user_id`='$userID'";
        $result = $this->dataQuery($sql);
        if (!empty($result)) {
            $IntakeInfo = "";
            foreach ($result as $value) {
                $IntakeID = $value['id'];
                $IntakeInfo .= $value['id'] . "~" . $value['date_id'] . "~" . $value['number'] . "~" . $value['each/times'];
            }
            $sqlDescription = "SELECT * FROM `medicine_description` WHERE `medicine_id`='$medicineID' AND `user_id`='$userID'";
            $resultDescription = $this->dataQuery($sqlDescription);
            if (!empty($resultDescription)) {
                foreach ($resultDescription as $value) {
                    $IntakeInfo .= "~" . $value['value'];
                }
            }
            $sqlIntakeDuration = "SELECT * FROM `medicine_intake_duration` WHERE `intake_id`='$IntakeID'";
            $resultIntakeDuration = $this->dataQuery($sqlIntakeDuration);
            if (!empty($resultIntakeDuration)) {
                foreach ($resultIntakeDuration as $value) {
                    $IntakeInfo .= "~" . $value['duration_id'] . "~" . $value['hrs'] . "~" . $value['intake_id'] . "~" . $value['after/before'];
                }
            }
            return $IntakeInfo;
        } else {
            return FALSE;
        }
    }

    public function update(array $data) {
        $sql = "UPDATE `medicine` SET `name`='$data[1]',`category_id`='$data[2]' WHERE id = '$data[0]'";
        if ($result = $this->booleanQuery($sql)) {
            return true;
        }
        return "error";

        return $result;
    }

    public function delete(array $data) {
        $sql = "DELETE FROM `medicine` WHERE id='$data[0]'";
        if ($result = $this->booleanQuery($sql)) {
            return true;
        }
        return false;
    }

    public function search($searchBy, $value) {

        $sql = "SELECT medicine.id, medicine.name, medicine_category.name FROM medicine INNER JOIN medicine_category ON medicine.category_id=medicine_category.id WHERE medicine.$searchBy LIKE '%$value%'";
        $result = $this->datafetch($sql);

        // print_r("mostafa".$result);
        return $result;
    }

    public function read_medicine_data() {
        $sql = "SELECT medicine.id, medicine.name, medicine_category.name FROM medicine_category INNER JOIN medicine ON  medicine_category.id=medicine.category_id";
        $result = $this->datafetch($sql);
        return $result;
    }

    public function getMaxID() {
        $sql = "SELECT max(`id`) FROM `medicine_intake`";
        $result = $this->dataQuery($sql);
        if (!empty($result)) {
            foreach ($result as $value) {
                $medicineIntakeID = $value['max(`id`)'];
            }
            return $medicineIntakeID;
        }
    }

}

<?php

include_once 'database.php';
include_once 'crud.php';

class duration extends database implements crud {

    public $id;
    public $day;
    public $from;
    public $to;

    public function create(array $data) {
        $workDurations = $data[0];

        $first = explode("^@", $workDurations);
        for ($i = 0; $i < count($first); $i++) {
            $second = explode("~", $first[$i]);
            for ($y = 0; $y < count($second); $y++) {
                switch ($y) {
                    case 0:
                        $this->day = $second[$y];
                        break;
                    case 1:
                        $this->from = $second[$y];
                        break;
                    case 2:
                        $this->to = $second[$y];
                        break;
                    default:
                        break;
                }
            }
            $duration = array($this->day, $this->from, $this->to);
            $readResult = $this->read($duration);
            if ($readResult == FALSE) {
                $sql = "INSERT INTO `duration`(`day_id`, `start`, `end`) VALUES ('$this->day','$this->from','$this->to')";
                $result = $this->booleanQuery($sql);
                if ($result != 1) {
                    break;
                }
                $readResult = $this->read($duration);
            }
            foreach ($readResult as $value) {
                $this->id = $value['id'];
            }
            $sql = "INSERT INTO `user_work_duration`(`user_id`, `duration_id`) VALUES ('$data[1]','$this->id')";
            $result = $this->booleanQuery($sql);
            if ($result != 1) {
                break;
            }
        }
        return $result;
    }

    public function addSingleDuration(array $data) {
        $this->day = $data[3];
        $this->from = $data[1];
        $this->to = $data[2];
        $sql = "INSERT INTO `duration`(`day_id`, `start`, `end`) VALUES ('$this->day','$this->from','$this->to')";
        $result = $this->booleanQuery($sql);
        if ($result == 1) {
            $sqlDurationID = "SELECT max(`id`) FROM `duration`";
            $result = $this->dataQuery($sqlDurationID);
        }
        return $result;
    }

    public function delete(array $data) {
        $sql = "DELETE FROM `user_work_duration` WHERE `user_id`='$data[1]'";
        $result = $this->booleanQuery($sql);
        return $result;
    }

    public function read(array $data) {
        //day, from, to
        $this->day = $data[0];
        $this->from = $data[1];
        $this->to = $data[2];

        $sql = "SELECT `id` FROM `duration` WHERE `day_id`='$this->day' AND `start`='$this->from' AND `end`='$this->to'";
        $result = $this->dataQuery($sql);
        if (!empty($result)) {
            return $result;
        }
        return FALSE;
    }

    public function readUserDurations($userID) {
        $sql = "SELECT * FROM `user_work_duration` WHERE `user_id`='$userID'";
        $result = $this->dataQuery($sql);
        $durations = array();
        if (!empty($result)) {
            foreach ($result as $value) {
                $this->id = $value['duration_id'];
                $durationSQL = "SELECT * FROM `duration` WHERE `id`='$this->id'";
                $durationResult = $this->dataQuery($durationSQL);
                if (!empty($durationResult)) {
                    foreach ($durationResult as $value2) {
                        array_push($durations, $value2['day_id']);
                        array_push($durations, $value2['start']);
                        array_push($durations, $value2['end']);
                        array_push($durations, $value2['id']);
                    }
                }
            }
        }
        return $durations;
    }

    public function update(array $data) {
        $deleteResult = $this->delete($data);
        if ($deleteResult == 1) {
            $result = $this->create($data);
            return $result;
        } else {
            return FALSE;
        }
    }

}

<?php
/**
 * Created by PhpStorm.
 * User: hammad
 * Date: 5/11/18
 * Time: 4:28 PM
 */

include_once 'database.php';
include_once 'crud.php';
class payment extends database implements crud
{

    public function create(array $data)
    {
       $sql="INSERT INTO `payment`(`type_id`, `submitted_by_id`) VALUES ($data[0],$data[1])";
        $result = $this->booleanQuery($sql);
        return $result;

    }

    public function read(array $data)
    {
        // TODO: Implement read() method.
    }

    public function update(array $data)
    {
        // TODO: Implement update() method.
    }

    public function delete(array $data)
    {
        // TODO: Implement delete() method.
    }

    public function get_max_id(){

        $sql="SELECT MAX(id)  FROM `payment` WHERE 1";
        $result=$this->dataQuery($sql);
        return $result;

    }



}
<div class="col-lg-12">
    <div class="block">
        <div class="title"><strong>Edit User Type</strong></div>

        <div class="block-body">
            <form class="form-horizontal">
                <div class="form-group row">
                    <label class="col-sm-3 form-control-label">Type</label>
                    <div class="col-sm-9 select">
                        <select id="type-list" name="account"  class="form-control mb-3 user-types" required>
                        </select>
                    </div>
                </div>

                <div  class="form-group row">
                    <label id="namelbl" class="col-sm-3 form-control-label">User Type Name</label>
                    <div class="col-sm-9">
                        <input id="usertypename" name="usertypename" placeholder="Enter User Type Name.." type="text" class="form-control usertypename" required>
                    </div>
                </div>
                <div  class="form-group row" id="selectt">
                    <label id="accesspagelbl" class="col-sm-3 form-control-label">Access Pages</label>
                    <div class="col-sm-9">
                        <select multiple='multiple' id='optgroup'>       
                        </select> 
                    </div>
                </div>

                <button id="cancel-user-type-btn" type="submit" class="btn btn-danger ml-auto  col-sm-5">Cancel</button>
                <button id="update-user-type-btn"type="Button" class="btn btn-primary col-sm-5 ml-auto">Update</button>

            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $("#update-user-type-btn").hide();
        $("#cancel-user-type-btn").hide();
        $("#namelbl").hide();
        $("#usertypename").hide();
        $("#accesspagelbl").hide();
        $("#selectt").hide();
    });

    jQuery.ajax({
        url: "../controller/get_user_types.php",
        method: 'POST',
        success: function (answer) {
            var arr = answer.split("~");
            var options = "";
            options += "<option>Select User Type..</option>";
            for (var i = 0; i < arr.length; i += 2) {
                options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
            }
            jQuery('.user-types').html(options);
        }
    });

    function get_user_access_by_id(usertypeid) {
        jQuery.ajax({
            url: "../controller/get_user_access.php",
            method: 'POST',
            data: {
                user_type_id: usertypeid,
            },
            success: function (answer) {
                var options = "";
                var arr = answer.split('~');
                if (arr == 0) {
                    options += "<optgroup label='No Data to show..'></optgroup>";
                }
                for (var i = 0; i < arr.length; i += 2) {
                    options += "<optgroup label='" + arr[i + 1] + "'><option selected value='" + arr[i] + "'>" + arr[i + 1] + "</option></optgroup>";
                }
                $("#optgroup").html(options);
                $('#optgroup').multiSelect({
                    selectableOptgroup: true,
                });
            }
        });
    }

    $(".user-types").change(function () {
        var optionvalue = $(".user-types").val();
        $("#optgroup").remove();
        var html = "<select multiple='multiple' id='optgroup'></select>";
        $('#selectt').children('.col-sm-9').html(html);
        get_user_access_by_id(optionvalue);
        $("#update-user-type-btn").show(500);
        $("#cancel-user-type-btn").show(500);
        $("#namelbl").show(500);
        $("#usertypename").show(500);
        $("#accesspagelbl").show(500);
        $("#selectt").show(500);
    });



    jQuery.ajax({
        url: "../controller/get_pages_access.php",
        method: 'POST',
        success: function (answer) {
            var arr = answer.split('!^@');
            var options = "";
            for (var i = 0; i < arr.length - 1; i++) {
                var arr2 = arr[i].split('~');
                if (arr2.length == 2) {
                    options += "<optgroup label='" + arr2[1] + "'><option value='" + arr2[0] + "'>" + arr2[1] + "</option></optgroup>";
                } else {
                    options += "<optgroup label='" + arr2[1] + "'>";
                    for (var j = 0; j < arr2.length; j += 2) {
                        options += "<option value='" + arr2[j] + "'>" + arr2[j + 1] + "</option>";
                    }
                    options += "</optgroup>";
                }
            }
            $("#optgroup").html(options);
            $('#optgroup').multiSelect({
                selectableOptgroup: true,
            });
        }
    });




    $("#update-user-type-btn").on("click", function (e) {
        e.preventDefault();
        jQuery.ajax({
            url: "../controller/edit_user_type.php",
            method: 'POST',
            data: {
                typeid: $(".user-types").val(),
                typename: $("#usertypename").val(),
                optgroup: $("#optgroup").val(),
            },
            success: function (answer) {
                if (answer) {
                    swal('Done!', 'Successfully Updated!', 'success');
                }
            }
        });
    });


    $("#cancel-user-type-btn").on("click", function (e) {
        e.preventDefault();
        location.reload();
    });

</script>



<div class="col-lg-12">
    <div class="block block1">
        <div class="title"><strong>Show User Types</strong></div>
        <div class="block-body">
            <form class="form-horizontal">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <button data-toggle="dropdown" type="button" id="id" class="btn btn-outline-secondary dropdown-toggle btn-dropdown" aria-expanded="true">ID <span class="caret"></span></button>
                                <div class="dropdown-menu btn-dropdown-menu">
                                    <a href="#" id="id" class="dropdown-item btn-dropdown-menu-item">ID</a>
                                    <a href="#" id="type" class="dropdown-item btn-dropdown-menu-item">Type</a>

                                </div>
                            </div>
                            <input type="text" class="form-control" placeholder="Search" id="search-input">
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <table class="table own-table show-employee-table rowtt-table" id="show_type_form">
            <thead class="thead-dark">
                <tr class="rowtt" id="table-head" class="no-action">
                    <th scope="col">#</th>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Type</th>
                </tr>
            </thead>
            <tbody>


            </tbody>
        </table>
    </div>
    <div class="block block2"></div>
</div>
<script>
    jQuery.ajax({
        url: "../controller/show_user_type.php",
        method: 'POST',
        success: function (answer) {
            var arr = answer.split("!^@");
            var rows = "";
            var counter = 1;
            for (var row = 0; row < arr.length; row++) {
                var arrValue = arr[row];
                var arr2 = arrValue.split("~");
                for (var data = 0; data < arr2.length; data += 5) {
                    rows += "<tr" + arr2[data] + " class='rowtt' id='" + arr2[data] + "'>";
                    for (var i = 0; i <= arr2.length; i++) {
                        if (i == 0) {
                            rows += "<th scope='row'>" + counter + "</th>";
                        } else {
                            rows += "<td>" + arr2[i - 1] + "</td>";
                        }
                    }
                    rows += "</tr>";
                    counter++;
                }
            }
            jQuery('table tbody').html(rows);
        }
    });
/*
    function showData(userID) {
        var url = "../controller/get_page.php";
        var id = $(".rowtt-table").attr("id");
        jQuery.ajax({
            url: url,
            data: {
                page: id
            },
            method: 'POST',
            success: function (answer) {
                $(".block").fadeOut(500, function () {
                    setEmployeeData(userID);
                    $('.block2').html(answer).fadeIn(500);
                    $(".btn-back").on("click", function (e) {
                        e.preventDefault();
                        $('.block2').fadeOut(500, function () {
                            $(".block1").fadeIn(500);
                        });
                    });
                    jQuery.ajax({
                        url: "../controller/show_employee_data.php",
                        data: {
                            userID: userID
                        },
                        method: 'POST',
                        success: function (answerr) {
//type_id /  name /  email / telephone / birthdate / ismale / salary / id
                            var arr = answerr.split("~");
                            $(".employee-types").val(arr[0]);
                            $(".name").val(arr[1]);
                            $(".form-name").html(arr[1]);
                            $(".email").val(arr[2]);
                            $(".mobile").val(arr[3]);
                            $(".DOB").val(arr[4]);
                            $(".salary").val(arr[6]);
                            var genderSelector = "input:radio[value=" + arr[5] + "]";
                            $(genderSelector).attr('checked', true);
                            $(".btn-update").attr("id", arr[7]);
                            $(".form-photo").attr("src", arr[8]);
                        }
                    });
                });
            }
        });
    }



    function setEmployeeData(userID) {
        jQuery.ajax({
            url: "../controller/get_employee_types.php",
            method: 'POST',
            success: function (answerrr) {
                var arr = answerrr.split("~");
                var options = "";
                for (var i = 0; i < arr.length; i += 2) {
                    options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
                }
                jQuery('.employee-types').html(options);
            }
        });

      
*/
    function searchType(searchBy) {
        var value = $("#search-input").val();
        jQuery.ajax({
            url: "../controller/search_type.php",
            method: 'POST',
            data: {
                searchBy: searchBy,
                value: value
            },
            success: function (answer) {
                if (answer != "") {
                    var arr = answer.split("!^@");
                    var rows = "";
                    var counter = 1;
                    for (var row = 0; row < arr.length; row++) {
                        var arrValue = arr[row];
                        var arr2 = arrValue.split("~");
                        for (var data = 0; data < arr2.length; data += 5) {
                            rows += "<tr" + arr2[data] + " class='rowtt' id='" + arr2[data] + "'>";
                            for (var i = 0; i <= arr2.length; i++) {
                                if (i == 0) {
                                    rows += "<th scope='row'>" + counter + "</th>";
                                } else {
                                    rows += "<td>" + arr2[i - 1] + "</td>";
                                }
                            }
                            rows += "</tr>";
                            counter++;
                        }
                    }
                    jQuery('table tbody').html(rows);
                } else {
                    jQuery('table tbody').html("");
                }
            }
        });
    }

    $(".btn-dropdown-menu-item").on("click", function () {
        $(".btn-dropdown").html($(this).html());
        $(".btn-dropdown").attr("id", $(this).attr("id"));
        $(".btn-dropdown-menu").toggleClass("show");

    });

    $("#search-input").on("keyup", function () {
        var searchBy = $(".btn-dropdown").attr("id");
        searchType(searchBy);
        
    });

    $(".btn-dropdown").on("click", function () {
        $(".btn-dropdown-menu").toggleClass("show");
    });
</script>
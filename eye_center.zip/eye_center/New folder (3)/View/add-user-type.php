<div class="col-lg-12">
    <div class="block">
        <div class="title"><strong>Add User Type</strong></div>

        <div class="block-body">
            <form class="form-horizontal">
                <div  class="form-group row">
                    <label id="namelbl" class="col-sm-3 form-control-label">User Type Name</label>
                    <div class="col-sm-9">
                        <input id="usertypename" name="usertypename" type="text" class="form-control" required>
                    </div>
                </div>

                <div  class="form-group row">
                    <label id="accesspagelbl" class="col-sm-3 form-control-label">Access Pages</label>
                    <div class="col-sm-9">
                        <select multiple='multiple' id='optgroup'>       
                        </select> 
                    </div>
                </div>
                <button id="cancel-user-type-btn" type="submit" class="btn btn-danger ml-auto  col-sm-5">Cancel</button>

                <button id="add-user-type-btn"type="Button" class="btn btn-primary col-sm-5 ml-auto">Add User Type</button>

            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    jQuery.ajax({
        url: "../controller/get_pages_access.php",
        method: 'POST',
        success: function (answer) {
alert(answer);
            var arr = answer.split('!^@');
            var options = "";
            for (var i = 0; i < arr.length - 1; i++) {
                var arr2 = arr[i].split('~');
                if (arr2.length == 2) {
                    options += "<optgroup label='" + arr2[1] + "'><option value='" + arr2[0] + "'>" + arr2[1] + "</option></optgroup>";
                } else {
                    options += "<optgroup label='" + arr2[1] + "'>";
                    for (var j = 0; j < arr2.length; j += 2) {
if(j!=0){
 options += "<option value='" + arr2[j] + "'>" + arr2[j + 1] + "</option>";

}
                       
                    }
                    options += "</optgroup>";
                }
            }
            $("#optgroup").html(options);
            $('#optgroup').multiSelect({
                selectableOptgroup: true,
            });
        }
    });

    $("#add-user-type-btn").on("click", function (e) {
        e.preventDefault();

        jQuery.ajax({
            url: "../controller/add_user_type.php",
            method: 'POST',
            data: {
                typename: $("#usertypename").val(),
                optgroup: $("#optgroup").val(),
            },
            success: function (answer) {
                if (answer) {
                    swal('Done!', 'Successfully Created!', 'success');
                }
                else {
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'User type is already exists !!'
                    });
                }
            }
        });
    });

    $("#cancel-user-type-btn").on("click", function (e) {
        e.preventDefault();
        location.reload();
    });

</script>

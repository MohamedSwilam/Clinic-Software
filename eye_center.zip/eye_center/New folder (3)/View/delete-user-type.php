
<div class="col-lg-12">
    <div class="block">
        <div class="title"><strong>Delete User Type</strong></div>

        <div class="block-body">
            <form class="form-horizontal">
                <div class="form-group row">
                    <label class="col-sm-3 form-control-label">Type</label>
                    <div class="col-sm-9 select">
                        <select id="type-list" name="account" class="form-control mb-3 user-types" required>
                        </select>
                    </div>
                </div>
                
                <button id="cancel-user-type-btn" type="submit" class="btn btn-danger ml-auto  col-sm-5">Cancel</button>
                <button id="delete-user-type-btn"type="Button" class="btn btn-primary ml-auto col-sm-5">Delete</button>

            </form>
        </div>
    </div>
</div>
<script>
    jQuery.ajax({
        url: "../controller/get_user_types.php",
        method: 'POST',
        success: function (answer) {
            var arr = answer.split("~");
            var options = "";
options +="<option>Select User Type..</option>";
            for (var i = 0; i < arr.length; i += 2) {
                options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
            }
            jQuery('.user-types').html(options);
        }
    });

    $(".user-types").change(function () {
        $("#delete-user-type-btn").show(500);
    });
    
    $("#delete-user-type-btn").on("click", function (e) {
        e.preventDefault();
        jQuery.ajax({
            url: "../controller/delete_user_type.php",
            method: 'POST',
            data: {
                typeid: $(".user-types").val(),
            },
            success: function (answer) {
            swal('Done!', 'Successfully Deleted!', 'success');
            }
        });
    });
    
</script>

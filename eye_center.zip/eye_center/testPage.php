<section class="dashboard-counts section-padding">
    <div class="container-fluid">
        <div class="row">

            <div class="col-xl-3 col-md-4 col-6 reservation-section reservation-section-active" id="total-reservations">
                <div class="wrapper count-title d-flex">
                    <div class="icon"><i class="icon-user"></i></div>
                    <div class="name"><strong class="text-uppercase">Total</strong><span>Total Reservations</span>
                        <div class="count-number total-reservations-number">-</div>
                    </div>
                </div>
            </div>
            <!-- Count item widget-->
            <div class="col-xl-3 col-md-4 col-6 reservation-section" id="missed-reservations">
                <div class="wrapper count-title d-flex">
                    <div class="icon"><i class="icon-list-1"></i></div>

                    <div class="name"><strong class="text-uppercase">Missed</strong><span>Missed Reservations</span>
                        <div class="count-number missed-reservations-number">-</div>
                    </div>
                </div>
            </div>
            <!-- Count item widget-->
            <div class="col-xl-3 col-md-4 col-6 reservation-section" id="today-reservations">
                <div class="wrapper count-title d-flex">
                    <div class="icon"><i class="icon-padnote"></i></div>
                    <div class="name"><strong class="text-uppercase">Today</strong><span>Today's Reservations</span>
                        <div class="count-number today-reservation-number">-</div>
                    </div>
                </div>
            </div>
            <!-- Count item widget-->
            <div class="col-xl-3 col-md-4 col-6 reservation-section" id="waiting-list">
                <div class="wrapper count-title d-flex">
                    <div class="icon"><i class="icon-list"></i></div>
                    <div class="name"><strong class="text-uppercase">Visits</strong><span>Waiting List</span>
                        <div class="count-number today-visits-number">-</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="col-lg-12">
    <div class="block block1">
        <div class="title"><strong>Reservation List</strong></div>
        <div class="block-body search-div">
            <form class="form-horizontal">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <button data-toggle="dropdown" type="button" id="id" class="btn btn-outline-secondary dropdown-toggle btn-dropdown" aria-expanded="true">ID <span class="caret"></span></button>
                                <div class="dropdown-menu btn-dropdown-menu">
                                    <a href="#" id="id" class="dropdown-item btn-dropdown-menu-item">ID </a>
                                    <a href="#" id="name" class="dropdown-item btn-dropdown-menu-item">Name </a>
                                    <a href="#" id="date" class="dropdown-item btn-dropdown-menu-item">Date </a>
                                    <a href="#" id="type" class="dropdown-item btn-dropdown-menu-item">Type </a>

                                </div>
                            </div>
                            <input type="text" class="form-control" placeholder="Search" id="search-input">
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <table class="table own-table show-reservations-table rowtt-table" id="show_reservations">

        </table>
    </div>
    <div class="block block2" style="display: none;">
        <div class="col-md-12">
            <div class="card text-white bg-primary">
                <div class="card-header card-header-transparent" id="card-header"><i class="fa fa-user"></i> &nbsp Patient Information</div>
                <div class="card-body">
                    <span class="col-md-2 info-label">ID: </span><span class="col-md-8 patient-id"></span><br>
                    <span class="col-md-2 info-label">Name: </span><span class="col-md-8 patient-name"></span><br>
                    <span class="col-md-2 info-label">Gender: </span><span class="col-md-8 patient-gender"></span><br>
                    <span class="col-md-2 info-label">Birthdate: </span><span class="col-md-8 patient-birthdate"></span><br>
                    <span class="col-md-2 info-label">Email: </span><span class="col-md-8 patient-email"></span><br>
                    <span class="col-md-2 info-label">Telephone: </span><span class="col-md-8 patient-telephone"></span>
                    <span class="col-md-2 info-label">Address: </span><span class="col-md-8 patient-address"></span>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card text-white bg-primary">
                <div class="card-header card-header-transparent" id="card-header"><i class="fa fa-wpforms"></i> &nbsp Reservation Information</div>
                <div class="card-body">
                    <span class="col-md-2 info-label">Type: </span><span class="col-md-8 reservation-type">Operative</span><br>
                    <span class="col-md-2 info-label">Doctor: </span><span class="col-md-8 reservation-doctor">Mohamed Ehab Swilam</span><br>
                    <span class="col-md-2 info-label">Date: </span><span class="col-md-8 reservation-date">30/4/2018</span><br>
                    <span class="col-md-2 info-label">Time: </span><span class="col-md-8 reservation-time">From 1:00 AM To 3:00 PM</span><br>
                    <span class="col-md-2 info-label">Room: </span><span class="col-md-8 reservation-room">Surgry 1</span><br>
                </div>
            </div>
        </div>

        <div class = "form-group row">
            <div class = "col-sm-12 ml-auto">
                <button class = "btn btn-primary col-sm-12 ml-auto go-back-btn">Go Back</button>
            </div>
        </div>
    </div>
    <div class="block block3" style="display: none;">
        <div class="col-md-12">
            <div class="card text-white bg-primary">
                <div class="card-header card-header-transparent" id="card-header"><i class="fa fa-user"></i> &nbsp Patient Information</div>
                <div class="card-body">
                    <span class="col-md-2 info-label">ID: </span><span class="col-md-8 patient-id"></span><br>
                    <span class="col-md-2 info-label">Name: </span><span class="col-md-8 patient-name"></span><br>
                    <span class="col-md-2 info-label">Gender: </span><span class="col-md-8 patient-gender"></span><br>
                    <span class="col-md-2 info-label">Birthdate: </span><span class="col-md-8 patient-birthdate"></span><br>
                    <span class="col-md-2 info-label">Email: </span><span class="col-md-8 patient-email"></span><br>
                    <span class="col-md-2 info-label">Telephone: </span><span class="col-md-8 patient-telephone"></span>
                    <span class="col-md-2 info-label">Address: </span><span class="col-md-8 patient-address"></span>
                </div>
            </div>
        </div>
        <div class = "form-group row">
            <div class = "col-sm-12 ml-auto">
                <center>
                    <button class = "btn Postponed col-sm-3 ml-auto postpone-btnn" onclick="btnUpdateStatus(this, 3)">Postpone</button>
                    <button style="border: none;" class = "btn btn-primary col-sm-3 ml-auto add-report-btn">Add Report</button>
                    <button class = "btn btn-success col-sm-3 ml-auto finish-btnn" onclick="btnUpdateStatus(this, 4)">Finish</button>
                </center>
            </div>
        </div>
        <div class="title"><strong>Timeline</strong></div>
        <div class="timeline two-column">
            <!-- Timeline header -->
            <div class="timeline-header">
                <div class="timeline-header-title bg-success">Now</div>
            </div>

            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon">
                        <img alt="Profile picture" src="../../images/8.png">
                    </div>
                    <div class="timeline-time">30 Min ago</div>
                </div>
                <div class="timeline-label">
                    <p class="mar-no pad-btm">
                        <a class="btn-link" href="#">Maria J.</a> shared an image</p>
                    <div class="img-holder">
                        <img alt="Image" src="../../images/img-2.jpg">
                    </div>
                </div>
            </div>
            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon">
                        <i class="demo-pli-office icon-2x"></i>
                    </div>
                    <div class="timeline-time">2 Hours ago</div>
                </div>
                <div class="timeline-label">
                    <h4 class="mar-no pad-btm"><a class="text-warning" href="#">Job Meeting</a></h4>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt.
                </div>
            </div>
            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon">
                        <img alt="Profile picture" src="../../images/9.png">
                    </div>
                    <div class="timeline-time">3 Hours ago</div>
                </div>
                <div class="timeline-label">
                    <p class="mar-no pad-btm">
                        <a class="btn-link" href="#">Lisa D.</a> commented on
                        <a href="#" class="text-semibold">The Article</a>
                    </p>
                    <blockquote class="bq-sm bq-open mar-no">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt.</blockquote>
                </div>
            </div>
            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon"><i class="demo-pli-twitter icon-2x"></i>
                    </div>
                    <div class="timeline-time">5 Hours ago</div>
                </div>
                <div class="timeline-label">
                    <img alt="Profile picture" src="../../images/3.png" class="img-xs img-circle">
                    <a class="btn-link" href="#">Bobby Marz</a> followed you.
                </div>
            </div>
            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon"><i class="demo-pli-mail icon-2x"></i>
                    </div>
                    <div class="timeline-time">15:45</div>
                </div>
                <div class="timeline-label">
                    <p class="text-main text-semibold">Lorem ipsum dolor sit amet</p>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt.
                </div>
            </div>
            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon bg-success"><i class="demo-psi-like icon-lg"></i>
                    </div>
                    <div class="timeline-time">13:27</div>
                </div>
                <div class="timeline-label">
                    <img alt="Profile picture" src="../../images/2.png" class="img-xs img-circle">
                    <a class="btn-link" href="#">Michael Both</a> Like <a href="#" class="text-semibold">The Article</a>
                </div>
            </div>
            <div class="timeline-entry">
                <div class="timeline-stat">
                    <div class="timeline-icon"></div>
                    <div class="timeline-time">11:27</div>
                </div>
                <div class="timeline-label">
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt.
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="block block4" style="display: none;">
        <div class="form-group row">
            <label class="col-sm-3 form-control-label">Form Name</label>
            <div class="col-sm-9 select">
                <select id="type-list" name="account" class="form-control mb-3 form-types" required="">

                </select>
            </div>
            <div class="code col-lg-12">
                <div class="title form-name-title"><strong></strong></div>
                <div class="form">

                </div>
                <div class="form-group row btns-div">
                    <div class="col-sm-12 ml-auto">
                        <center>
                            <button id="cancel-form-btn" type="submit" class="btn btn-danger col-sm-5 ml-auto">Cancel</button>
                            <button id="add-form-btn" style="display: none;" type="submit" class="btn btn-success col-sm-5 ml-auto">Submit</button>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="block block5" style="display: none;">
        <form class="form-horizontal" id="medicine-intake-form"  action="" method="post" enctype="multipart/form-data">
            <div class="form-group row cancel-to-4">
                <div class="col-sm-12 ml-auto">
                    <button type="submit" class="btn btn-danger col-sm-5 ml-auto">Cancel</button>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-3 form-control-label">Medicine</label>
                <div class="col-sm-9 select">
                    <select id="medicine-list2" disabled name="medicine" class="form-control mb-3 medicine" required>
                        <option class="no">Select Medicine</option>
                    </select>
                </div>
            </div>
            <div style="display: none" class="form-group row description">
                <label class="col-sm-3 form-control-label">Description</label>
                <div class="col-sm-9">
                    <textarea id="description" class="form-control" name="description"></textarea>
                </div>
            </div>
            <div style="display: none" class="form-group row deal">
                <label class="col-sm-3 form-control-label">Deals With</label>
                <div class="col-sm-9 select">
                    <select id="deal-list" name="deal" class="form-control mb-3" required>
                        <option class="no">Select Item</option>
                        <option>Day</option>
                        <option>Week</option>
                        <option>Month</option>
                        <option>Year</option>
                    </select>
                </div>
            </div>
            <div style="display: none" class="form-group row numberOfTimesDiv">
                <label class="col-sm-3 form-control-label">Number of times</label>
                <div class="col-sm-3">
                    <input type="number" name="numberOfTimes" class="form-control numberOfTimes" min="1" max="999" maxlength="3" required>
                </div>
            </div>
            <div style="display: none" class="form-group row doseType">
                <label class="col-sm-3 form-control-label">Dose Type</label>
                <div class="col-sm-9 dose-type-engine">
                    <div class="i-checks">
                        <input id="radioCustom1" type="radio" checked="false" value="0" name="doseType" class="radio-template">
                        <label for="radioCustom1">2 doses per day</label>
                    </div>
                    <div class="i-checks">
                        <input id="radioCustom2" type="radio" checked="false" value="1" name="doseType" class="radio-template">
                        <label for="radioCustom2">1 dose each 2 days</label>
                    </div> 
                </div>
            </div>
            <div class="form-group row btn-dose-div" style="display: none" >
                <div class="col-sm-4">
                    <div id="add-dose-intake-duration" class="btn btn-success col-sm-12 ml-auto btn-dose">+ Add Dose Intake duration</div>
                </div>
            </div>
            <div class="form-group row dose-table" style="display: none">
                <div class="col-sm-12 ml-auto">
                    <table class="table own-table dose-info-table rowtt-table" id="dose-info-table">
                        <thead class="thead-dark">
                            <tr class="rowtt" id="table-head" class="no-action">
                                <th scope="col">Dose</th>
                                <th scope="col">Duration</th>
                                <th scope="col">After/Before</th>
                                <th scope="col">Hours</th>                                    
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
            <br><br>
            <center>
                <div class="form-group row div-btn-success" style="display: none">
                    <div class="col-sm-12 ml-auto">
                        <button id="add-intake-btn" type="submit" class="btn btn-success col-sm-5 ml-auto">Submit</button>
                    </div>
                </div>
            </center>
        </form>
    </div>
</div>
<script>
    $(".add-report-btn").on("click", function () {
        $(".form").hide();
        $.ajax({
            url: "../controller/get_user_forms.php",
            data: {
                userID: user_id
            },
            method: "POST",
            success: function (answer) {
                var arr = answer.split("~");
                var options = "<option class='new'>Select Item</option>";
                for (var i = 0; i < arr.length; i += 2) {
                    options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
                }
                $(".form-types").html(options);
                $(".block3, .block2, .block1, .dashboard-counts").fadeOut("slow", function () {
                    $(".block4").fadeIn("slow");
                });
            }
        });
    });

    function setInputsData() {
        $(".form-name-title strong").html($(".form-types option:selected").text());
        $(".form .form-group").each(function (index, value) {
            if ($(value).hasClass("section-input")) {
                var element = $(value).children("div:last-child").children("input");
                var inputName = element.attr("id");
                var inputType = element.attr("type");
                if (inputType == "Text") {
                    set_input_id(inputName, "1", element, false);
                } else if (inputType == "Number") {
                    set_input_id(inputName, "2", element, false);
                } else if (inputType == "Email") {
                    set_input_id(inputName, "3", element, false);
                } else if (inputType == "Date") {
                    set_input_id(inputName, "4", element, false);
                } else if (inputType == "file") {
                    set_input_id(inputName, "5", element, false);
                    var inputName = "img" + index;
                    $(value).children("div:last-child").children("input").attr("name", "file");
                } else if (inputType == "Time") {
                    set_input_id(inputName, "6", element, false);
                }
            } else if ($(value).hasClass("section-textarea")) {
                var element = $(value).children("div:last-child").children("textarea");
                var inputName = element.attr("id");
                set_input_id(inputName, "10", element, false);
            } else if ($(value).hasClass("section-dropdown")) {
                var element = $(value).children(".select").children("select");
                var inputName = element.attr("id");
                set_input_id(inputName, "7", element, index);
            } else if ($(value).hasClass("section-checkbox")) {
                var element = $(value).children("div");
                var inputName = element.attr("id");
                set_input_id(inputName, "9", element, index);
            } else if ($(value).hasClass("section-radiobutton")) {
                var element = $(value).children("div");
                var inputName = element.attr("id");
                set_input_id(inputName, "8", element, index);
            } else if ($(value).hasClass("section-medicine")) {
                $(value).html("<div class='input-div section-medicine col-lg-12'><div class='row section-header col-md-12'><label class='col-sm-2 form-control-label'>Select Medicine:</label> <div class='col-sm-12 select'><select id='medicine-list' class='form-control mb-3 medicine-types'></select></div></div><div class='form-group row section-body col-md-12'><table class='table own-table rowtt-table medicine-table-form'><thead class='thead-dark'><tr id='table-head' class='no-action'><th scope='col'>Medicine Name</th><th scope='col'>Intake</th><th scope='col'>Update Intake</th><th scope='col'>Remove Medicine</th></tr></thead><tbody><tr class='no-medicines'><td colspan='4'><center>No Medicines Selected</center></td></tr> </tbody></table></div></div>");
                set_medicine_dropdown();
            }
        });
        $(".code, #add-form-btn").fadeIn();
    }

    function set_medicine_dropdown() {
        $.ajax({
            url: "../controller/get_medicine.php",
            method: "POST",
            success: function (answer) {
                var arr = answer.split("~");
                var option = "<option class='select-item'>Select Medicine</option>";
                for (var j = 0; j < arr.length; j += 2) {
                    option += "<option value='" + arr[j] + "'>" + arr[j + 1] + "</option>";
                }
                $("#medicine-list").html(option);
            }
        });

        $("#medicine-list").on("change", function () {
            $(".select-item").remove();
            var medicineID = $(this).val();
            $("#medicine-list option:selected").hide();
            $.ajax({
                url: "../controller/get_medicine_intake.php",
                method: "POST",
                data: {
                    medicineID: medicineID,
                    userID: user_id
                }, success: function (answer) {
                    var arr = answer.split("~");
                    var dates = ['day', 'week', 'month', 'year'];
                    var row = "<tr id='med-" + medicineID + "'>";
                    row += "<td id='" + arr[0] + "'>" + $("#medicine-list option:selected").text() + "</td>";
                    row += "<td>";
                    if (arr.length > 1) {
                        if (arr[3] == 1) { // each
                            row += "1 dose each " + arr[2] + " " + dates[arr[1] - 1];
                        } else { // times
                            row += arr[2] + " doses per " + dates[arr[1] - 1];
                        }
                    } else {
                        row += "No Intake Submitted!";
                    }
                    row += "</td>";
                    row += "<td><button class='btn-success editbtn' onclick='updateIntake(" + medicineID + ",this)'>Update Intake</button></td>";
                    row += "<td><button class='btn-danger btn-del' onclick='removeMedicine(this, " + medicineID + ")'>Remove Medicine</button></td>";
                    row += "</tr>";
                    $(".no-medicines").hide();
                    $(".medicine-table-form tbody").append(row);
                }
            });
        });
    }

    function updateIntake(medicineID, element) {
        $(".block4").fadeOut(function () {
            set_intake_inputs(medicineID, element);
            $(".block5").fadeIn();
        });
    }

    function removeMedicine(element, medicineID) {
        $(element).parent().parent().remove();
        var selector = "#medicine-list option[value='" + medicineID + "']";
        $(selector).show();
    }

    function set_input_id(inputName, inputType, element, setInputChilds) {
        $.ajax({
            url: "../controller/get_input_id.php",
            method: "POST",
            data: {
                inputName: inputName,
                type: inputType
            }, success: function (answer) {
                $(element).attr("id", answer);
                if (setInputChilds != false) {
                    set_input_childs(answer, inputType, element, setInputChilds);
                }
            }
        });
    }

    function set_input_childs(inputID, inputType, element, index) {
        $.ajax({
            url: "../controller/get_input_childs.php",
            method: "POST",
            data: {
                inputID: inputID
            },
            success: function (answer) {
                var arr = answer.split("!^@");
                var option = "";
                if (inputType == 7) {
                    for (var i = 0; i < arr.length; i++) {
                        var arr2 = arr[i].split("~");
                        for (var j = 0; j < arr2.length; j += 2) {
                            option += "<option value='" + arr2[j] + "'>" + arr2[j + 1] + "</option>";
                        }
                    }
                } else if (inputType == 9) {
                    for (var i = 0; i < arr.length; i++) {
                        var arr2 = arr[i].split("~");
                        for (var j = 0; j < arr2.length; j += 2) {
                            option += "<div class='i-checks'><input id='checkboxCustom2' type='checkbox' value='" + arr2[j] + "' class='checkbox-template'><label for='checkboxCustom2'>" + arr2[j + 1] + "</label></div>";
                        }
                    }
                } else if (inputType == 8) {
                    for (var i = 0; i < arr.length; i++) {
                        var arr2 = arr[i].split("~");
                        for (var j = 0; j < arr2.length; j += 2) {
                            option += "<div class='i-checks'><input id='radioCustom1' type='radio' value='" + arr2[j] + "' name='a" + index + "' class='radio-template'><label for='radioCustom1'>" + arr2[j + 1] + "</label></div>";
                        }
                    }
                }
                element.html(option);
            }
        });
    }

    $("#add-form-btn").on("click", function () {
        var inputName = [];
        var values = [];
        var medicines = [];
        var data = new FormData();
        $(".code .form .form-group").each(function (index, value) {
            if ($(value).hasClass("section-input")) {
                var inputType = $(value).children("div:last-child").children("input").attr("type");
                if (inputType == "file") {
                    var id = $(value).children("div:last-child").children("input").attr("id");
                    var name = document.getElementById(id).files[0].name;
                    var form_data = new FormData();
                    var ext = name.split('.').pop().toLowerCase();
                    if (jQuery.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                        alert("Invalid Image File");
                    }
                    var oFReader = new FileReader();
                    oFReader.readAsDataURL(document.getElementById(id).files[0]);
                    var f = document.getElementById(id).files[0];
                    var fsize = f.size || f.fileSize;
                    if (fsize > 2000000) {
                        alert("Image File Size is very big");
                    } else {
                        form_data.append("file", document.getElementById(id).files[0]);
                        $.ajax({
                            url: "../controller/add_form_images.php",
                            method: "POST",
                            data: form_data,
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function (answer) {
                                inputName.push($(value).children("div:last-child").children("input").attr("id"));
                                values.push(answer);
                            }
                        });
                    }
                } else {
                    inputName.push($(value).children("div:last-child").children("input").attr("id"));
                    values.push($(value).children("div:last-child").children("input").val());
                }
            } else if ($(value).hasClass("section-textarea")) {
                inputName.push($(value).children("div:last-child").children("textarea").attr("id"));
                values.push($(value).children("div:last-child").children("textarea").val());
            } else if ($(value).hasClass("section-dropdown")) {
                inputName.push($(value).children("div:last-child").children("select").attr("id"));
                values.push($(value).children("div:last-child").children("select").val());
            } else if ($(value).hasClass("section-checkbox")) {
                $(value).children("div:last-child").children(".i-checks").each(function (index2, element2) {
                    inputName.push($(element2).children("input:checkbox").val());
                    if ($(element2).children("input:checkbox").is(':checked')) {
                        values.push("1");
                    } else {
                        values.push("0");
                    }
                });
            } else if ($(value).hasClass("section-radiobutton")) {
                inputName.push($(value).children("div:last-child").attr("id"));
                var name = $(value).children("div:last-child").children(".i-checks:first-child").children("input").attr("name");
                var selector = "input[name='" + name + "']:checked";
                values.push($(selector).val());
            } else if ($(value).hasClass("section-medicine")) {
                $(value).children("div:last-child").children("div:last-child").children("table").children("tbody").children("tr").each(function (indexx, elementt) {
                    if ($(elementt).hasClass("no-medicines")) {

                    } else {
                        medicines.push($(value).children("div:last-child").children("div:last-child").children("table").children("tbody").children("tr").children("td:first-child").attr("id"));
                    }
                });
            }
        });
        var patientID = $(".block3 .patient-id").html();
        data.append("inputNames", inputName);
        data.append("values", values);
        data.append("formID", $(".form-types").val());
        data.append("userID", user_id);
        data.append("patientID", patientID);
        var date = new Date();
        var month = date.getMonth() + 1;
        var currentDate = date.getUTCFullYear() + "-" + month + "-" + date.getDate();
        data.append("currentDate", currentDate);
        if (medicines.length > 0) {
            data.append("medicines", medicines);
        }
        $.ajax({
            type: 'POST',
            url: '../controller/add_form_data.php',
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            success: function (answer) {
                alert(answer);
            }
        });

    });

    $("#cancel-form-btn").on("click", function () {
        $(".block4").fadeOut("slow", function () {
            $(".block3").fadeIn();
        });
    });

    $(".form-types").on("change", function () {
        $(".new").remove();
        $(".form").fadeIn();
        var formID = $(this).val();
        $.ajax({
            url: "../controller/get_form_code.php",
            method: "POST",
            data: {
                formID: formID
            },
            success: function (answer) {

                $(".code").fadeOut("slow", function () {
                    $(".form").html(answer);
                    setInputsData();

                });
            }
        });
    });

    $(".reservation-section").on("click", function () {
        $(".reservation-section").removeClass("reservation-section-active");
        $(this).addClass("reservation-section-active");

        var section = $(this).attr("id");

        if (section == "total-reservations") {
            getAllReservationInfo("user.id", "");
            $(".search-div").show();
        } else if (section == "today-reservations") {
            getTodayReservationInfo("user.id", "");
            $(".search-div").show();
        } else if (section == "missed-reservations") {
            getMissedReservationInfo("user.id", "");
            $(".search-div").show();
        } else if (section == "waiting-list") {
            getVisitedReservations("", "");
            $(".search-div").hide();
        }
    });

    function setReservationStatistics() {
        jQuery.ajax({
            url: "../controller/get_doctor_reservation_statistics.php",
            method: 'POST',
            data: {
                doctorID: user_id
            },
            success: function (answer) {
                var arr = answer.split("~");
                $('.total-reservations-number').html(arr[0]);
                $('.missed-reservations-number').html(arr[1]);
                $('.today-reservation-number').html(arr[2]);
                $('.today-visits-number').html(arr[3]);
            }
        });
    }

    setReservationStatistics();

    function time12format(timee) {
        var arr = timee.split(":");
        var newTimeFormat = "";
        var ampm = "PM";
        var hrs = parseInt(arr[0]) - 12;
        if (hrs < 0) {
            ampm = "AM";
            hrs = parseInt(arr[0]);
        }

        if (hrs == 0) {
            hrs = 12;
        }
        newTimeFormat += hrs + ":" + arr[1] + " " + ampm;
        return newTimeFormat;
    }

    function getPatientReservationInfo(patientID) {
        $.ajax({
            url: "../controller/get_all_patient_info.php",
            method: 'POST',
            data: {
                patientID: patientID
            },
            success: function (answer) {
                var arr = answer.split("~");
                var genders = ['Female', 'Male'];
                $(".patient-id").html(arr[0]);
                $(".patient-name").html(arr[1]);
                $(".patient-birthdate").html(arr[2]);
                $(".patient-gender").html(genders[arr[3]]);
                $(".patient-email").html(arr[4]);
                $(".patient-telephone").html(arr[5]);
                $(".patient-address").html(arr[6]);
                $.ajax({
                    url: "../controller/get_all_reservation_info.php",
                    method: 'POST',
                    data: {
                        patientID: patientID
                    },
                    success: function (answer) {
                        var arr = answer.split("~");
                        $(".reservation-type").html(arr[1]);
                        $(".reservation-doctor").html(arr[0]);
                        $(".reservation-date").html(arr[2]);
                        var duration = "From " + time12format(arr[3]) + " to " + time12format(arr[4]);
                        $(".reservation-time").html(duration);
                        $(".reservation-room").html(arr[5]);

                    }
                });
            }
        });
    }

    function getAllReservationInfo(searchBy, value) {
        jQuery.ajax({
            url: "../controller/get_reservation_info.php",
            method: 'POST',
            data: {
                searchBy: searchBy,
                value: value
            },
            success: function (answer) {
                var arr = answer.split("!^@");
                var rows = "<thead class='thead-dark'><tr id='table-head'  class='no-action'><th scope='col'>#</th><th scope='col'>ID</th><th scope='col'>Patient Name</th><th scope='col'>Reservation Type</th><th scope='col'>Date</th><th scope='col'>Duration</th><th scope='col'>Room</th></tr></thead><tbody>";
                var counter = 1;
                for (var row = 0; row < arr.length; row++) {
                    var arrValue = arr[row];
                    var arr2 = arrValue.split("~");
                    if (arr2.length > 2) {
                        if (arr2[7] == user_id) {
                            rows += "<tr class='rowtt' id='" + arr2[0] + "'>";
                            rows += "<th scope='row'>" + counter + "</th>";
                            rows += "<td>" + arr2[0] + "</td>";
                            rows += "<td>" + arr2[1] + "</td>";
                            rows += "<td>" + arr2[2] + "</td>";
                            rows += "<td>" + arr2[3] + "</td>";
                            var fromTo = arr2[4].split("-");
                            var from = time12format(fromTo[0]);
                            var to = time12format(fromTo[1]);
                            rows += "<td>" + from + " - " + to + "</td>";
                            rows += "<td>" + arr2[5] + "</td>";
                            rows += "</tr>";
                            counter++;
                        }
                    }
                }
                rows += "</tbody>";
                jQuery('.show-reservations-table').html(rows);
                $(".rowtt").on('click', function () {
                    var id = $(this).attr("id");
                    getPatientReservationInfo(id);
                    $(".dashboard-counts").fadeOut("slow");
                    $(".block1").fadeOut("slow", function () {
                        $(".block2").fadeIn("slow");
                    });
                });
            }
        });
    }

    function getMissedReservationInfo(searchBy, value) {
        jQuery.ajax({
            url: "../controller/get_missed_reservation_info.php",
            method: 'POST',
            data: {
                searchBy: searchBy,
                value: value
            },
            success: function (answer) {
                var arr = answer.split("!^@");
                var rows = "<thead class='thead-dark'><tr id='table-head' class='no-action'><th scope='col'>#</th><th scope='col'>ID</th><th scope='col'>Patient Name</th><th scope='col'>Reservation Type</th><th scope='col'>Date</th><th scope='col'>Duration</th><th scope='col'>Room</th></tr></thead><tbody>";
                var counter = 1;
                for (var row = 0; row < arr.length; row++) {
                    var arrValue = arr[row];
                    var arr2 = arrValue.split("~");
                    if (arr2.length > 2) {
                        if (arr2[6] == user_id) {
                            rows += "<tr class='rowtt' id='" + arr2[0] + "'>";
                            rows += "<th scope='row'>" + counter + "</th>";
                            rows += "<td>" + arr2[0] + "</td>";
                            rows += "<td>" + arr2[1] + "</td>";
                            rows += "<td>" + arr2[2] + "</td>";
                            rows += "<td>" + arr2[3] + "</td>";
                            var fromTo = arr2[4].split("-");
                            var from = time12format(fromTo[0]);
                            var to = time12format(fromTo[1]);
                            rows += "<td>" + from + " - " + to + "</td>";
                            rows += "<td>" + arr2[5] + "</td>";
                            rows += "</tr>";
                            counter++;
                        }
                    }
                }
                rows += "</tbody>";
                jQuery('.show-reservations-table').html(rows);
                $(".rowtt").on('click', function () {
                    var id = $(this).attr("id");
                    getPatientReservationInfo(id);
                    $(".dashboard-counts").fadeOut("slow");
                    $(".block1").fadeOut("slow", function () {
                        $(".block2").fadeIn("slow");
                    });
                });
            }
        });
    }

    function getVisitedReservations(searchBy, value) {
        jQuery.ajax({
            url: "../controller/get_visited_reservations.php",
            method: 'POST',
            data: {
                searchBy: searchBy,
                value: value
            },
            success: function (answer) {
                var arr = answer.split("!^@");
                var rows = "<thead class='thead-dark'><tr id='table-head'  class='no-action'><th scope='col'>#</th><th scope='col'>ID</th><th scope='col'>Patient Name</th><th scope='col'>Reservation Type</th><th scope='col'>Room</th><th scope='col'>Status</th><th scope='col'>Action</th></tr></thead><tbody>";
                var counter = 1;
                for (var row = 0; row < arr.length; row++) {
                    var arrValue = arr[row];
                    var arr2 = arrValue.split("~");
                    if (arr2.length > 2) {
                        if (arr2[7] == user_id) {
                            if (arr2[4] == 4) {
                                rows += "<tr class='rowtt row-finished' id='" + arr2[0] + "'>";
                            } else {
                                rows += "<tr class='rowtt' id='" + arr2[0] + "'>";
                            }
                            rows += "<th scope='row'>" + counter + "</th>";
                            rows += "<td>" + arr2[0] + "</td>";
                            rows += "<td>" + arr2[1] + "</td>";
                            rows += "<td>" + arr2[2] + "</td>";
                            rows += "<td>" + arr2[3] + "</td>";
                            rows += "<td><span class='visit-status " + arr2[5] + "'>" + arr2[5] + "</span></td>";
                            if (arr2[4] == 1) {
                                rows += "<td><button id='" + arr2[4] + "~" + arr2[6] + "' class='btn-success editbtn visit-action begin-btn'>Begin</button></td>";
                            } else if (arr2[4] == 2) {
                                rows += "<td><button id='" + arr2[4] + "~" + arr2[6] + "' class='btn-success editbtn visit-action edit-profile-btn'>Edit Profile</button></td>";
                            } else if (arr2[4] == 3) {
                                rows += "<td><button id='" + arr2[4] + "~" + arr2[6] + "' class='btn-success editbtn visit-action continue-btn'>Continue</button></td>";
                            } else if (arr2[4] == 4) {
                                rows += "<td><button id='" + arr2[4] + "~" + arr2[6] + "' class='btn-success editbtn visit-action finished-btn'>Update Status</button></td>";
                            }
                            rows += "</tr>";
                            counter++;
                        }
                    }
                }
                rows += "</tbody>";
                jQuery('.show-reservations-table').html(rows);
                $(".rowtt").on('click', function () {
                    var id = $(this).attr("id");
                    getPatientReservationInfo(id);
                    $(".dashboard-counts").fadeOut("slow");
                    $(".block1").fadeOut("slow", function () {
                        $(".block2").fadeIn("slow");
                    });
                }).on('click', '.visit-action', function (e) {
                    e.stopPropagation();
                    var id = $(this).attr("id").split("~");
                    var statusID = id[0];
                    var reservationID = id[1];
                    var patientID = $(this).parent().parent().attr("id");

                    if (statusID == 1 || statusID == 3) {
                        $.ajax({
                            url: "../controller/get_visited_reservations.php",
                            method: "POST",
                            data: {
                                searchBy: 'visit.id',
                                value: ''
                            },
                            success: function (answer) {
                                var arr = answer.split("!^@");
                                var patientExists = false;
                                var oldReservationID;
                                for (var row = 0; row < arr.length; row++) {
                                    var arr2 = arr[row].split("~");
                                    if (arr2[4] == 2) {
                                        patientExists = true;
                                        oldReservationID = arr2[6];
                                        break;
                                    }
                                }
                                if (patientExists) {
                                    var inputOptions = {
                                        '3': 'Postpone',
                                        '4': 'Finish'
                                    };

                                    swal({
                                        text: "What action do you prefer on existing patient?",
                                        title: 'A paient already exists with you!',
                                        type: 'info',
                                        input: 'radio',
                                        inputOptions: inputOptions,
                                        inputClass: "test-class",
                                        allowOutsideClick: false,
                                        showCancelButton: true,
                                        confirmButtonClass: "action-btn2",
                                        confirmButtonText: "Submit Action!",
                                        inputValidator: function (value) {
                                            return !value && 'You need to choose an action!';
                                        }
                                    });

                                    $(".action-btn2").on("click", function () {
                                        var actionValue = $("input[name=swal2-radio]:checked").val();
                                        updateStatus(actionValue, oldReservationID, false);
                                        updateStatus(2, reservationID, true);

                                    });
                                } else {
                                    updateStatus(2, reservationID, true);
                                }

                            }
                        });
                    } else if (statusID == 2) {
                        getPatientReservationInfo(patientID);
                        $(".block1, .block2, .dashboard-counts").fadeOut("slow", function () {
                            $(".postpone-btnn, .finish-btnn").attr("id", reservationID);
                            $(".block3").fadeIn();
                        });
                    } else if (statusID == 4) {
                        var inputOptions = {
                            '2': 'Inside',
                            '3': 'Postpone'
                        };

                        swal({
                            text: "What action do you prefer on existing patient?",
                            title: 'A paient already exists with you!',
                            type: 'info',
                            input: 'radio',
                            inputOptions: inputOptions,
                            confirmButtonClass: "action-btn",
                            allowOutsideClick: false,
                            showCancelButton: true,
                            confirmButtonText: "Submit Action!",
                            inputValidator: function (value) {
                                return !value && 'You need to choose an action!';
                            }
                        });

                        $(".action-btn").on("click", function () {
                            var actionValue = $("input[name=swal2-radio]:checked").val();
                            if (actionValue == 2) {
                                $.ajax({
                                    url: "../controller/get_visited_reservations.php",
                                    method: "POST",
                                    data: {
                                        searchBy: 'visit.id',
                                        value: ''
                                    },
                                    success: function (answer) {
                                        var arr = answer.split("!^@");
                                        var patientExists = false;
                                        var oldReservationID;
                                        for (var row = 0; row < arr.length; row++) {
                                            var arr2 = arr[row].split("~");
                                            if (arr2[4] == 2) {
                                                patientExists = true;
                                                oldReservationID = arr2[6];
                                                break;
                                            }
                                        }
                                        if (patientExists) {
                                            var inputOptions = {
                                                '3': 'Postpone',
                                                '4': 'Finish'
                                            };

                                            swal({
                                                text: "What action do you prefer on existing patient?",
                                                title: 'A paient already exists with you!',
                                                type: 'info',
                                                input: 'radio',
                                                inputOptions: inputOptions,
                                                inputClass: "test-class",
                                                allowOutsideClick: false,
                                                showCancelButton: true,
                                                confirmButtonClass: "action-btn2",
                                                confirmButtonText: "Submit Action!",
                                                inputValidator: function (value) {
                                                    return !value && 'You need to choose an action!';
                                                }
                                            });
                                            $(".action-btn2").on("click", function () {
                                                var actionValue = $("input[name=swal2-radio]:checked").val();
                                                updateStatus(actionValue, oldReservationID, false);
                                                updateStatus(2, reservationID, true);
                                            });
                                        } else {
                                            updateStatus(2, reservationID, true);
                                        }
                                    }
                                });
                            } else {
                                updateStatus(actionValue, reservationID, true);
                            }
                        });
                    }
                });
            }
        });
    }

    function btnUpdateStatus(element, statusID) {
        var reservationID = $(element).attr("id");
        updateStatus(statusID, reservationID, true);
        $(".block3").fadeOut("slow", function () {
            $(".block1, .dashboard-counts").fadeIn("slow");
        });
    }

    function updateStatus(statusID, reservationID, updateTable) {
        $.ajax({
            url: "../controller/update_status.php",
            method: "POST",
            data: {
                statusID: statusID,
                reservationID: reservationID
            },
            success: function (answer) {
                if (answer == 1 && updateTable == true) {
                    getVisitedReservations("visit.id", "");
                }
            }
        });
    }

    function getTodayReservationInfo(searchBy, value) {
        jQuery.ajax({
            url: "../controller/get_today_reservation_info.php",
            method: 'POST',
            data: {
                searchBy: searchBy,
                value: value
            },
            success: function (answer) {
                var arr = answer.split("!^@");
                var rows = "<thead class='thead-dark'><tr id='table-head'  class='no-action'><th scope='col'>#</th><th scope='col'>ID</th><th scope='col'>Patient Name</th><th scope='col'>Reservation Type</th><th scope='col'>Date</th><th scope='col'>Duration</th><th scope='col'>Room</th></tr></thead><tbody>";
                var counter = 1;
                for (var row = 0; row < arr.length; row++) {
                    var arrValue = arr[row];
                    var arr2 = arrValue.split("~");
                    if (arr2.length > 2) {
                        if (arr2[7] == user_id) {
                            rows += "<tr class='rowtt' id='" + arr2[0] + "'>";
                            rows += "<th scope='row'>" + counter + "</th>";
                            rows += "<td>" + arr2[0] + "</td>";
                            rows += "<td>" + arr2[1] + "</td>";
                            rows += "<td>" + arr2[2] + "</td>";
                            rows += "<td>" + arr2[3] + "</td>";
                            var fromTo = arr2[4].split("-");
                            var from = time12format(fromTo[0]);
                            var to = time12format(fromTo[1]);
                            rows += "<td>" + from + " - " + to + "</td>";
                            rows += "<td>" + arr2[5] + "</td>";
                            rows += "</tr>";
                            counter++;
                        }
                    }
                }
                rows += "</tbody>";
                jQuery('.show-reservations-table').html(rows);
                $(".rowtt").on('click', function () {
                    var id = $(this).attr("id");
                    getPatientReservationInfo(id);
                    $(".dashboard-counts").fadeOut("slow");
                    $(".block1").fadeOut("slow", function () {
                        $(".block2").fadeIn("slow");
                    });
                });
            }
        });
    }

    getAllReservationInfo("user.id", "");

    $(".go-back-btn").on("click", function (e) {
        e.preventDefault();
        $(".block2").fadeOut("slow", function () {
            $(".block1, .dashboard-counts").fadeIn("slow");
        });
    });

    $(".btn-dropdown-menu-item").on("click", function () {
        $(".btn-dropdown").html($(this).html());
        $(".btn-dropdown").attr("id", $(this).attr("id"));
        $(".btn-dropdown-menu").toggleClass("show");
    });

    $("#search-input").on("keyup", function () {
        var searchWith = $(".btn-dropdown").attr("id");
        if (searchWith == "id") {
            searchWith = "user.id";
        } else if (searchWith == "name") {
            searchWith = "user.name";
        } else if (searchWith == "date") {
            searchWith = "date.date";
        } else if (searchWith == "type") {
            searchWith = "reservation_type.type";
        }

        if ($("#total-reservations").hasClass("reservation-section-active")) {
            getAllReservationInfo(searchWith, $(this).val());
            $(".search-div").show();
        } else if ($("#today-reservations").hasClass("reservation-section-active")) {
            getTodayReservationInfo(searchWith, $(this).val());
            $(".search-div").show();
        } else if ($("#missed-reservations").hasClass("reservation-section-active")) {
            getMissedReservationInfo(searchWith, $(this).val());
            $(".search-div").show();
        } else if ($("#waiting-list").hasClass("reservation-section-active")) {
            $(".search-div").hide();
            getVisitedReservations("", "");
        }
    });

    $(".btn-dropdown").on("click", function () {
        $(".btn-dropdown-menu").toggleClass("show");
    });

    function set_intake_inputs(medicineID, element) {
        $("#medicine-list2 .no").remove();
        $("#medicine-list2").val(medicineID);
        var data = new FormData();
        data.append('medicineID', medicineID);
        data.append('userID', user_id);
        if ($(element).parent().parent().hasClass("edited")) {
            data.append('patientID', $(".patient-id").html());
        }
        $.ajax({
            url: "../controller/get_medicine_intake.php",
            type: "POST",
            data: data,
            processData: false,
            contentType: false,
            success: function (answer) {
                alert(answer);
                if (answer == false) {
                    $(".block5 .description").fadeIn();
                    $(".block5 #description").val("");
                    $(".block5 .deal").fadeIn();
                    $(".block5 .deal, .numberOfTimes").val("");
                    $(".block5 .numberOfTimesDiv, .doseType, .btn-dose-div, .dose-table").fadeOut();
                    $(".block5 #add-intake-btn").removeClass("update");
                    $(".block5 #add-intake-btn").html("Add Intake");
                    $(".block5 .div-btn-success").fadeOut();
                } else {
                    var arr = answer.split("~");
                    var counter = 0;
                    for (var i = 0; i < arr.length; i++) {
                        counter++;
                    }
                    var deal = arr[1];
                    var numberOfTimes = arr[2];
                    var intakeType = arr[3];
                    var description = "";
                    var startLoop = 4;
                    if (counter % 2 == 1) {
                        startLoop = 5;
                        description = arr[4];
                    }
                    $(".block5 #description").val(description);
                    $(".block5 .description").fadeIn();

                    $(".block5 #deal-list").val(deal);
                    $(".block5 .deal").fadeIn();

                    $(".block5 .numberOfTimes").val(numberOfTimes);
                    $(".block5 .numberOfTimesDiv").fadeIn();

                    displayDurationOptions(numberOfTimes);
                    var selector = "input[name=doseType][value='" + intakeType + "']";
                    $(selector).prop("checked", true);
                    $(".block5 .doseType").fadeIn();
                    $(".block5 .btn-dose-div").fadeIn();
                    $(".block5 #add-intake-btn").addClass("update");
                    $(".block5 #add-intake-btn").html("Update Intake");
                    $(".block5 .div-btn-success").fadeIn();
                    if (counter > 5) {
                        $(".block5 .dose-table").fadeIn();
                        $("#add-dose-intake-duration").removeClass("btn-success");
                        $("#add-dose-intake-duration").addClass("btn-danger");
                        if ($("#add-dose-intake-duration").hasClass("btn-success")) {
                            $("#add-dose-intake-duration").html("+ Add Dose Intake Duration");
                        } else {
                            $("#add-dose-intake-duration").html("- Remove Dose Intake Duration");
                            var doseTypeValue = parseInt($("input[type=radio][name=doseType]:checked").val());
                            var numberOfDoseIntakeDurations = 0;
                            if (doseTypeValue == 1) {
                                numberOfDoseIntakeDurations = 1;
                            } else {
                                numberOfDoseIntakeDurations = parseInt($(".numberOfTimes").val());
                            }
                            var durationRowsHTML = "";
                            var options = "<option class='no'>Select Duration</option>";
                            $.ajax({
                                url: "../controller/get_medicine_durations.php",
                                method: "POST",
                                success: function (answer) {
                                    var arr2 = answer.split("~");
                                    for (var i = 0; i < arr2.length; i += 2) {
                                        options += "<option value='" + arr2[i] + "'>" + arr2[i + 1] + "</option>";
                                    }
                                    for (var i = 0; i < numberOfDoseIntakeDurations; i++) {
                                        var id = i + 1;
                                        var dealClass = "deal-" + id;
                                        var afterBeforeName = "afterBefore" + id;
                                        var numberOfHoursClass = "number-of-hours-" + id;
                                        durationRowsHTML += "<tr>\n\
                                    <td>" + id + "</td>\n\
                                    <td>\n\
                                        <select name='deal' class='form-control mb-12 " + dealClass + "'>" + options + "\n\
                                        </select>\n\
                                    </td>\n\
                                    <td>\n\
                                        <div class='col-sm-12'>\n\
                                            <div class='i-checks'>\n\
                                                <input type='radio' value='0' name='" + afterBeforeName + "' class='radio-template'>\n\
                                                <label>After</label>\n\
                                            </div> \n\
                                            <div class='i-checks'>\n\
                                                <input type='radio' value='1' name='" + afterBeforeName + "' class='radio-template'>\n\
                                                <label>Before</label>\n\
                                            </div> \n\
                                        </div>\n\
                                    </td>\n\
                                    <td>\n\
                                        <input type='number' class='form-control " + numberOfHoursClass + "'>\n\
                                    </td>\n\
                                    </tr>";
                                    }
                                    $(".dose-info-table tbody").html(durationRowsHTML);

                                    var counter2 = 1;
                                    for (var i = startLoop; i < arr.length; i += 4) {
                                        var id = counter2;
                                        var dealClass = ".deal-" + id;
                                        var afterBeforeSelector = "input[name=afterBefore" + id + "][value='" + arr[i + 3] + "']";
                                        var numberOfHoursClass = ".number-of-hours-" + id;
                                        $(dealClass).val(arr[i]);
                                        $(afterBeforeSelector).prop("checked", true);
                                        $(numberOfHoursClass).val(arr[i + 1]);
                                        counter2++;
                                    }

                                }
                            });
                        }
                    } else {
                        $(".block5 .dose-table").fadeOut();
                        $(".block5 #add-dose-intake-duration").addClass("btn-success");
                        $(".block5 #add-dose-intake-duration").removeClass("btn-danger");
                        $(".block5 #add-dose-intake-duration").html("+ Add Dose Intake Duration");
                    }
                }
            }
        });

        AddIntakeControl(element);
    }
    function displayDurationOptions(value) {
        var deal = $(".deal option:selected").text().toLowerCase();
        var deal2 = deal;
        if (value > 1) {
            deal2 += "s";
        }
        var durationOptions = "<div class='i-checks'><input id='radioCustom' type='radio' checked='false' value='0' name='doseType' class='radio-template'><label for='radioCustom'>" + value + " doses per " + deal + "</label></div><div class='i-checks'><input id='radioCustom2' type='radio' checked='false' value='1' name='doseType' class='radio-template'><label for='radioCustom2'>1 dose each " + value + " " + deal2 + "</label></div>";
        $(".dose-type-engine").html(durationOptions);
        $('input:radio[name=doseType]:checked').prop('checked', false);
        $('input[type=radio][name=doseType]').on('change', function () {
            $(".block5 .btn-dose-div, .block5 .div-btn-success").fadeIn();
            $(".dose-table").fadeOut();
            if ($("#add-dose-intake-duration").hasClass("btn-danger")) {
                $("#add-dose-intake-duration").addClass("btn-success");
                $("#add-dose-intake-duration").removeClass("btn-danger");
                $("#add-dose-intake-duration").html("+ Add Dose Intake Duration");
            }
        });
    }

    $(".deal").on("change", function () {
        $(".deal .no").remove();
        $(".numberOfTimesDiv").fadeIn();
        var value = $(".numberOfTimes").val();
        if (value != "") {
            displayDurationOptions(value);
        }
    });

    $(".numberOfTimes").on("keyup", function () {
        var value = $(this).val();

        $(".dose-table, .btn-dose-div, .div-btn-success").fadeOut();
        if ($("#add-dose-intake-duration").hasClass("btn-danger")) {
            $("#add-dose-intake-duration").addClass("btn-success");
            $("#add-dose-intake-duration").removeClass("btn-danger");
            $("#add-dose-intake-duration").html("+ Add Dose Intake Duration");
        }

        if (value == "") {
            $(".doseType").fadeOut();
        } else if (parseInt(value) <= 0) {
            $(this).val("");
            $(".doseType").fadeOut();
        } else if (parseInt(value) > 999) {
            $(this).val("999");
            $(".doseType").fadeOut();
        } else {
            displayDurationOptions(value);
            $(".doseType").fadeIn();
        }
    });

    function getMedicineDurations() {
        $.ajax({
            url: "../controller/get_medicine_durations.php",
            method: "POST",
            success: function (answer) {
                var arr = answer.split("~");
                var options = "<option class='no'>Select Duration</option>";
                for (var i = 0; i < arr.length; i += 2) {
                    options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
                }
                return options;
            }
        });
    }

    $(".btn-dose").on("click", function () {
        $(".dose-table").toggle();
        $("#add-dose-intake-duration").toggleClass("btn-success");
        $("#add-dose-intake-duration").toggleClass("btn-danger");
        if ($("#add-dose-intake-duration").hasClass("btn-success")) {
            $("#add-dose-intake-duration").html("+ Add Dose Intake Duration");
        } else {
            $("#add-dose-intake-duration").html("- Remove Dose Intake Duration");
            var doseTypeValue = parseInt($("input[type=radio][name=doseType]:checked").val());
            var numberOfDoseIntakeDurations = 0;
            if (doseTypeValue == 1) {
                numberOfDoseIntakeDurations = 1;
            } else {
                numberOfDoseIntakeDurations = parseInt($(".numberOfTimes").val());
            }
            var durationRowsHTML = "";
            var options = "<option class='no'>Select Duration</option>";
            $.ajax({
                url: "../controller/get_medicine_durations.php",
                method: "POST",
                success: function (answer) {
                    var arr = answer.split("~");
                    for (var i = 0; i < arr.length; i += 2) {
                        options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
                    }
                    for (var i = 0; i < numberOfDoseIntakeDurations; i++) {
                        var id = i + 1;
                        var dealClass = "deal-" + id;
                        var afterBeforeName = "afterBefore" + id;
                        var numberOfHoursClass = "number-of-hours-" + id;
                        durationRowsHTML += "<tr>\n\
                                    <td>" + id + "</td>\n\
                                    <td>\n\
                                        <select name='deal' class='form-control mb-12 " + dealClass + "'>" + options + "\n\
                                        </select>\n\
                                    </td>\n\
                                    <td>\n\
                                        <div class='col-sm-12'>\n\
                                            <div class='i-checks'>\n\
                                                <input type='radio' value='0' name='" + afterBeforeName + "' class='radio-template'>\n\
                                                <label>After</  label>\n\
                                            </div> \n\
                                            <div class='i-checks'>\n\
                                                <input type='radio' value='1' name='" + afterBeforeName + "' class='radio-template'>\n\
                                                <label>Before</label>\n\
                                            </div> \n\
                                        </div>\n\
                                    </td>\n\
                                    <td>\n\
                                        <input type='number' class='form-control " + numberOfHoursClass + "'>\n\
                                    </td>\n\
                                    </tr>";
                    }
                    $(".dose-info-table tbody").html(durationRowsHTML);
                }
            });
        }
    });

    $.ajax({
        url: "../controller/get_medicine.php",
        method: "POST",
        success: function (answer) {
            var arr = answer.split("~");
            var options = "<option class='no'>Select Medicine</option>";
            for (var i = 0; i < arr.length; i += 2) {
                options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
            }
            jQuery('#medicine-list2').html(options);
        }
    });

    $.ajax({
        url: "../controller/get_medicine_date.php",
        method: "POST",
        success: function (answer) {
            var arr = answer.split("~");
            var options = "<option class='no'>Select Item</option>";
            for (var i = 0; i < arr.length; i += 2) {
                options += "<option value='" + arr[i] + "'>" + arr[i + 1] + "</option>";
            }
            jQuery('#deal-list').html(options);
        }
    });


    function AddIntakeControl(element) {
        $("#add-intake-btn").on("click", function (e) {
            e.preventDefault();
            var medicineID = $("#medicine-list2").val();
            var description = $("#description").val();
            var deal = $("#deal-list").val();
            var numberOfTimes = $(".numberOfTimes").val();
            var doseType = $("input[type=radio][name=doseType]:checked").val();
            var numberOfDoseIntakeDurations = 0;
            var doseIntakeDurations = [];
            if ($("#add-dose-intake-duration").hasClass("btn-danger")) {
                if (doseType == 1) {
                    numberOfDoseIntakeDurations = 1;
                } else {
                    numberOfDoseIntakeDurations = parseInt($(".numberOfTimes").val());
                }
                for (var i = 0; i < numberOfDoseIntakeDurations; i++) {
                    var id = i + 1;
                    var dealClass = ".deal-" + id;
                    var afterBeforeName = "input[type=radio][name=afterBefore" + id + "]:checked";
                    var numberOfHoursClass = ".number-of-hours-" + id;
                    doseIntakeDurations.push($(dealClass).val());
                    doseIntakeDurations.push($(afterBeforeName).val());
                    doseIntakeDurations.push($(numberOfHoursClass).val());
                }
            } else {
                doseIntakeDurations.push("none");
            }
            if ($(this).hasClass("update")) {
                $.ajax({
                    url: "../controller/update_medicine_intake.php",
                    method: "POST",
                    data: {
                        medicineID: medicineID,
                        description: description,
                        deal: deal,
                        numberOfTimes: numberOfTimes,
                        doseType: doseType,
                        numberOfDoseIntakeDurations: numberOfDoseIntakeDurations,
                        doseIntakeDurations: doseIntakeDurations,
                        userID: $(".patient-id").html()
                    },
                    success: function (answer) {
                        if (answer == 1) {
                            $.ajax({
                                url: "../controller/get_last_medicine_intake.php",
                                method: "POST",
                                success: function (answer) {
                                    $(element).parent().parent().children("td:nth(0)").attr("id", answer);
                                }
                            });
                        } else {
                            swal({
                                type: 'error',
                                title: 'Oops...',
                                text: answer
                            });
                        }
                    }
                });
            } else {
                $.ajax({
                    url: "../controller/add_medicine_intake.php",
                    method: "POST",
                    data: {
                        medicineID: medicineID,
                        description: description,
                        deal: deal,
                        numberOfTimes: numberOfTimes,
                        doseType: doseType,
                        numberOfDoseIntakeDurations: numberOfDoseIntakeDurations,
                        doseIntakeDurations: doseIntakeDurations,
                        userID: $(".patient-id").html()
                    },
                    success: function (answer) {
                        if (answer == 1) {
                            $.ajax({
                                url: "../controller/get_last_medicine_intake.php",
                                method: "POST",
                                success: function (answer) {
                                    $(element).parent().parent().children("td:nth(0)").attr("id", answer);
                                }
                            });
                        } else {
                            swal({
                                type: 'error',
                                title: 'Oops...',
                                text: answer
                            });
                        }
                    }
                });
            }
            var rowIntakeData = "";
            var dates = ['day', 'week', 'month', 'year'];
            if (doseType == 1) { // each
                rowIntakeData += "1 dose each " + numberOfTimes + " " + dates[deal];
            } else { // times
                rowIntakeData += numberOfTimes + " doses per " + dates[deal];
            }
            $(element).parent().parent().children("td:nth(1)").html(rowIntakeData);
            $(element).parent().parent().addClass("edited");

            $(".block5").fadeOut(function () {
                $(".block4").fadeIn();
            });
        });
    }

    $(".cancel-to-4").on("click", function (e) {
        e.preventDefault();
        $(".block5").fadeOut(function () {
            $(".block4").fadeIn();
        });
    });


</script>